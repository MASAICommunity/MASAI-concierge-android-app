package com.mogree.travel_buddy.core.communication;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.util.Patterns;

import com.embiq.communicationmanager.CommunicationManager;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.gson.Gson;
import com.mogree.travel_buddy.chat.ChatUtilities;
import com.mogree.travel_buddy.core.helper.C;
import com.mogree.travel_buddy.core.helper.GCMHelper;
import com.mogree.travel_buddy.core.helper.JsonHelper;
import com.mogree.travel_buddy.core.helper.OkHttpHelper;
import com.mogree.travel_buddy.core.helper.RealmHelper;
import com.mogree.travel_buddy.core.model.Host;
import com.mogree.travel_buddy.core.model.Message;
import com.mogree.travel_buddy.core.model.MessageAttachment;
import com.mogree.travel_buddy.core.model.RoomId;
import com.mogree.travel_buddy.core.model.RoomSubscription;
import com.mogree.travel_buddy.core.model.SyncState;
import com.mogree.travel_buddy.core.model.Token;
import com.mogree.travel_buddy.core.model.User;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;

import bolts.Continuation;
import bolts.Task;
import chat.rocket.android_ddp.DDPClient;
import chat.rocket.android_ddp.DDPClientCallback;
import chat.rocket.android_ddp.DDPSubscription;
import chat.rocket.android_ddp.rx.RxWebSocketCallback;
import io.realm.Realm;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okio.BufferedSink;
import okio.Okio;
import okio.Source;
import rx.functions.Action1;


public class HostConnection {
    private Host host;
    private User user;
    private DDPClient ddpClient;
    private String sessionUUID;
    private boolean loggedIn = false;
    private Handler handler;
    private String tokenString;
    private int connectionListPosition;

    HostConnection(Host host, User user) {
        this.host = host;
        this.user = user;
        sessionUUID = UUID.randomUUID().toString();
    }

    private static Continuation getBasicErrorContinuationObject(final IBaseErrorCallback baseErrorCallback) {
        return new Continuation<Object, Object>() {
            @Override
            public Object then(Task<Object> task) throws Exception {
                if (task.getError() != null) {
                    C.L("ERROR");
                    baseErrorCallback.onErrorDuringConnection();
                }
                return null;
            }
        };
    }

    public static void resetPassword(final String email, final IResetPasswordCallback resetPasswordCallback) {
        Task.callInBackground(new Callable<Object>() {
            @Override
            public Object call() throws Exception {
                OkHttpClient.Builder builder = new OkHttpClient.Builder();
                builder.readTimeout(0, TimeUnit.NANOSECONDS);
                OkHttpClient okHttpClient = builder.build();
                DDPClient ddpClient = new DDPClient(okHttpClient);
                ddpClient.connect("http://demo.masai.solutions:2999/websocket").continueWith(new Continuation<DDPClientCallback.Connect, Task<Object>>() {
                    @Override
                    public Task<Object> then(Task<DDPClientCallback.Connect> task) throws Exception {
                        final DDPClientCallback.Connect result = task.getResult();
                        C.L("jh" + result.session);
                        JSONArray jsonArray = new JSONArray().put(email);
                        task.getResult().client.rpc(C.RPC_RESET_PASSWORD, jsonArray, UUID.randomUUID().toString(), C.TIMEOUT_MS).continueWith(new Continuation<DDPClientCallback.RPC, Object>() {
                            @Override
                            public Object then(Task<DDPClientCallback.RPC> task) throws Exception {
                                C.L("reset password returned + " + task.getResult().result);
                                if (task.getResult().result.equals("true")) {
                                    resetPasswordCallback.onPasswordReset();
                                } else {
                                    resetPasswordCallback.onErrorDuringConnection();
                                }
                                return null;
                            }
                        }).continueWith(getBasicErrorContinuationObject(resetPasswordCallback));
                        return null;
                    }
                }).continueWith(getBasicErrorContinuationObject(resetPasswordCallback));
                return null;
            }
        });
    }

    public static void registerUser(final String name, final String email, final String pass, final IRegisterCallback registerCallback) {
        Task.callInBackground(new Callable<Object>() {
            @Override
            public Object call() throws Exception {
                OkHttpClient.Builder builder = new OkHttpClient.Builder();
                builder.readTimeout(0, TimeUnit.NANOSECONDS);
                OkHttpClient okHttpClient = builder.build();
                DDPClient ddpClient = new DDPClient(okHttpClient);
                ddpClient.connect("http://demo.masai.solutions:2999/websocket").continueWith(new Continuation<DDPClientCallback.Connect, Task<Object>>() {
                    @Override
                    public Task<Object> then(Task<DDPClientCallback.Connect> task) throws Exception {
                        final DDPClientCallback.Connect result = task.getResult();
                        C.L("jh" + result.session);
                        JSONArray jsonArray = new JSONArray().put(new JSONObject().put(C.JSON_FIELD_NAME, name).put(C.JSON_FIELD_EMAIL, email).put(C.JSON_FIELD_PASS, pass).put(C.JSON_FIELD_CONFIRM_PASS, pass));
                        task.getResult().client.rpc(C.RPC_REGISTER_USER, jsonArray, UUID.randomUUID().toString(), C.TIMEOUT_MS).continueWith(new Continuation<DDPClientCallback.RPC, Object>() {
                            @Override
                            public Object then(Task<DDPClientCallback.RPC> task) throws Exception {
                                C.L("register returned + " + task.getResult().result);
                                registerCallback.onRegistered();
                                return null;
                            }
                        }).continueWith(getBasicErrorContinuationObject(registerCallback));
                        return null;
                    }
                }).continueWith(getBasicErrorContinuationObject(registerCallback));
                return null;
            }
        });
    }

    public void setUser(User user) {
        this.user = user;
    }

    private void getRooms(final DDPClient client, final IGetRoomsCallback roomsCallback) {
        Task.callInBackground(new Callable<Object>() {
            @Override
            public Object call() throws Exception {
                C.L("trying to get rooms");
                client.rpc(C.RPC_GET_ROOMS, new JSONArray(), sessionUUID, C.TIMEOUT_MS).onSuccess(new Continuation<DDPClientCallback.RPC, Object>() {
                    @Override
                    public Object then(Task<DDPClientCallback.RPC> task2) throws Exception {
                        RoomSubscription subscriptions[] = new Gson().fromJson(task2.getResult().result, RoomSubscription[].class);
                        C.L("rooms returned + " + task2.getResult().result);
                        roomsCallback.onRoomsReady(subscriptions);
                        return null;
                    }
                }).continueWith(getBasicErrorContinuationObject(roomsCallback));
                return null;
            }
        });
    }

    public void setUsername(final String username, final IConnectLoginAndSetUsernameCallback listener) {
        C.L("trying to createAChannel");
        final JSONArray jsonArray = new JSONArray().put(username);
        C.L("channel create with json" + jsonArray);
        ddpClient.rpc(C.RPC_SET_USERNAME, jsonArray, UUID.randomUUID().toString(), C.TIMEOUT_MS).continueWith(new Continuation<DDPClientCallback.RPC, Object>() {
            @Override
            public Object then(Task<DDPClientCallback.RPC> task2) throws Exception {
                C.L("set username returned" + task2.getResult().result);
                task2.getResult().client.rpc(C.RPC_JOIN_CHANNELS, new JSONArray(), sessionUUID, C.TIMEOUT_MS).continueWith(new Continuation<DDPClientCallback.RPC, Object>() {
                    @Override
                    public Object then(final Task<DDPClientCallback.RPC> task) throws Exception {
                        C.L("join channels returned" + task.getResult().result);
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                getMe(connectionListPosition, new IConnectAndLoginCallback() {
                                    @Override
                                    public void onConnectedAndLoggedIn() {
                                        C.L("I downloaded myself againg");
                                        listener.onUsernameSet();
                                    }

                                    @Override
                                    public void onNoUsername() {
                                        C.L("getMe error");
                                        listener.onErrorDuringConnection();
                                    }

                                    @Override
                                    public void onErrorDuringConnection() {
                                        C.L("getMe error");
                                        listener.onErrorDuringConnection();
                                    }
                                });
                            }
                        });
                        listener.onUsernameSet();
                        return null;
                    }
                }).continueWith(getBasicErrorContinuationObject(listener));
                return null;
            }
        }).continueWith(getBasicErrorContinuationObject(listener));
    }

    void connectAndLogin(final IConnectAndLoginCallback connectAndLoginCallback) {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.readTimeout(0, TimeUnit.NANOSECONDS);
        OkHttpClient okHttpClient = builder.build();
        loggedIn = false;
        ddpClient = new DDPClient(okHttpClient);
        handler = new Handler();
        if (host.getToken() != null && !host.getToken().isEmpty()) {
            tokenString = host.getToken();
        }
        ddpClient.connect(host.getHostUrl()).continueWith(new Continuation<DDPClientCallback.Connect, Task<Object>>() {
            @Override
            public Task<Object> then(Task<DDPClientCallback.Connect> task) throws Exception {
                final DDPClientCallback.Connect result = task.getResult();
                C.L("jh" + result.session);
                result.client.getSubscriptionCallback().subscribe(new Action1<DDPSubscription.Event>() {
                    @Override
                    public void call(DDPSubscription.Event event) {
                        C.L("Callback[Subscription] " + event.toString());
                    }
                });
                task.getResult().client.getOnCloseCallback().continueWith(new Continuation<RxWebSocketCallback.Close, Object>() {
                    @Override
                    public Object then(Task<RxWebSocketCallback.Close> task) throws Exception {
                        C.L("close " + task.getResult().toString());
                        return null;
                    }
                });
                if (!loggedIn) {
                    if (tokenString != null) {
                        loginWithToken(task.getResult().client, connectAndLoginCallback);
                    } else {
                        loginWithPass(task.getResult().client, connectAndLoginCallback);
                    }
                }
                return null;
            }
        }).continueWith(getBasicErrorContinuationObject(connectAndLoginCallback));
    }

    public void subscribe() {
        C.L("TRYING TO SUBSCRIBE");
        Task.callInBackground(new Callable<Object>() {
            @Override
            public Object call() throws Exception {
                ddpClient.sub(UUID.randomUUID().toString(), "stream-room-messages", new JSONArray().put(host.getRoomId()).put(false)).continueWith(new Continuation<DDPSubscription.Ready, Object>() {
                    @Override
                    public Object then(Task<DDPSubscription.Ready> task) throws Exception {
                        C.L("Subscription successful?");
                        return null;
                    }
                }).continueWith(new Continuation<Object, Object>() {
                    @Override
                    public Object then(Task<Object> task) throws Exception {
                        C.L("Subscription UNsuccessful?");
                        return null;
                    }
                });
                return null;
            }
        });
    }

    private void checkLoginResultAndParseToken(String result, final IConnectAndLoginCallback connectAndLoginCallback) {
        C.L("logged in  token + " + result);
        final Token token = new Gson().fromJson(result, Token.class);
        if (token != null) {
            ConnectionManager.getInstance().getUser().setId(token.getId());
            loggedIn = true;
            handler.post(new Runnable() {
                @Override
                public void run() {
                    RealmHelper.getInstance().executeCustomTransaction(new Realm.Transaction() {
                        @Override
                        public void execute(Realm realm) {
                            host.setToken(token.getToken(), token.getTokenExpires());
                            realm.copyToRealmOrUpdate(host);
                            getMe(connectionListPosition, connectAndLoginCallback);
                        }
                    });
                    C.L("logged in and parsed token + " + token.getToken());
                    RealmHelper.getInstance().updateHost(host);
                    C.L("logged in and parsed token + " + token.getToken());
                }
            });
        } else {
            connectAndLoginCallback.onErrorDuringConnection();
        }
    }

    private void getMe(final int pos, final IConnectAndLoginCallback connectAndLoginCallback) {
        final String hostUrl = ConnectionManager.getInstance().getHostConnectionForPos(pos).getHost().getHostRocketChatApiUrl();
        C.L("ASDFASDFASDF " + hostUrl);
        final String token = ConnectionManager.getInstance().getHostConnectionForPos(pos).getHost().getToken();
        Task.callInBackground(new Callable<Object>() {
            @Override
            public Object call() throws Exception {
                CustomRequests.getInfoAboutMe(hostUrl, token, ConnectionManager.getInstance().getUser().getId(), new CustomRequests.SimpleHttpResponseListener() {
                    @Override
                    public void onSuccess() {
                        if (user.getUsername() == null || user.getUsername().isEmpty()) {
                            connectAndLoginCallback.onNoUsername();
                        } else {
                            connectAndLoginCallback.onConnectedAndLoggedIn();
                        }
                    }

                    @Override
                    public void onFail() {
                        connectAndLoginCallback.onErrorDuringConnection();
                    }
                });
                return null;
            }
        });
    }

    private void loginWithToken(final DDPClient client, final IConnectAndLoginCallback connectAndLoginCallback) {
        try {
            JSONArray jArray = new JSONArray().put(new JSONObject().put("resume", tokenString));
            C.L("log in with token json = " + jArray.toString());

            client.rpc(C.RPC_LOGIN, jArray, sessionUUID, C.TIMEOUT_MS).continueWith(new Continuation<DDPClientCallback.RPC, Object>() {
                @Override
                public Object then(Task<DDPClientCallback.RPC> task) throws Exception {
                    C.L("logged in with token + " + task.getResult().result);
                    checkLoginResultAndParseToken(task.getResult().result, connectAndLoginCallback);
                    return null;
                }
            }).continueWith(getBasicErrorContinuationObject(connectAndLoginCallback));
        } catch (JSONException e) {
            e.printStackTrace();
            connectAndLoginCallback.onErrorDuringConnection();
        }
    }

    public void loadMessagesFromWhileIWasAway(final String roomId, final IGetMessagesCallback listener) {
        C.L("loadMessagesFromWhileIWasAway1");
        Message message = RealmHelper.getInstance().getFirstMessage(connectionListPosition);
        C.L("loadMessagesFromWhileIWasAway2");
        if (message == null) {
            C.L("loadMessagesFromWhileIWasAway2.5");
            long ts = System.currentTimeMillis();
            C.L("loadMessagesFromWhileIWasAway3 for roomid " + roomId);
            loadHistory(roomId, 0, 50, ts, listener);
        } else {
            C.L("loadMessagesFromWhileIWasAway4");
            loadHistory(roomId, 0, 50, 0, listener);
        }
    }

    public void loadOlderMessages(final IGetMessagesCallback listener) {
        Message firstMessage = RealmHelper.getInstance().getFirstMessage(connectionListPosition);
        if (firstMessage != null) {
            loadHistory(host.getRoomId(), firstMessage.getTimeStamp(), 50, 0, listener);
        }
    }

    private void loadHistory(final String roomId, final long timestamp, final int count, final long lastSeen, final IGetMessagesCallback listener) {
        C.L("SAFE loadHistory");
        try {
            JSONArray requestDataJsonArray = new JSONArray()
                    .put(roomId)
                    .put(timestamp > 0 ? new JSONObject().put(C.JSON_FIELD_DATE, timestamp) : JSONObject.NULL)
                    .put(count)
                    .put(lastSeen > 0 ? new JSONObject().put(C.JSON_FIELD_DATE, lastSeen) : JSONObject.NULL);
            C.L("history trying to download with json=" + requestDataJsonArray.toString());
            ddpClient.rpc(C.RPC_LOAD_HISTORY, requestDataJsonArray, UUID.randomUUID().toString(), C.TIMEOUT_MS).continueWith(new Continuation<DDPClientCallback.RPC, Object>() {
                @Override
                public Object then(Task<DDPClientCallback.RPC> task2) throws Exception {
                    C.L("messages downloaded = " + task2.getResult().result);
                    String modedJsonString = JsonHelper.simplifyDate(task2.getResult().result);
                    C.L("messages downloaded and moded = " + modedJsonString);
                    JSONObject messagesJsonObject = new JSONObject(modedJsonString);
                    if (messagesJsonObject.has(C.JSON_FIELD_MESSAGES)) {
                        final JSONArray messageJsonArray = messagesJsonObject.getJSONArray(C.JSON_FIELD_MESSAGES);
                        for (int co0 = 0; co0 < messageJsonArray.length(); ++co0) {
                            messageJsonArray.getJSONObject(co0).put(C.JSON_FIELD_POS_ON_THE_LIST, connectionListPosition);
                        }
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                RealmHelper.getInstance().addMessagesFromJson(messageJsonArray, connectionListPosition);
                                listener.onMessagesReady();
                            }
                        });
                    }
                    return null;
                }
            }).continueWith(getBasicErrorContinuationObject(listener));
        } catch (JSONException je) {
            je.printStackTrace();
            listener.onErrorDuringConnection();
        }
    }

    public void resendMessage(final Handler mainHandler, final int messagePos, final ISendMessagesCallback listener, final ISendFileCallback fileListener, final String roomName) {
        C.L("trying to REsend message");
        handler.post(new Runnable() {
            @Override
            public void run() {
                List<Message> messageList = RealmHelper.getInstance().getMessages(connectionListPosition);
                if (messagePos <= messageList.size()) {
                    Message message = messageList.get(messagePos - 1);
                    if (message != null && message.getSyncstate() == SyncState.FAILED) {
                        String filePath = null;
                        if (message.getAttachments() != null) {
                            for (MessageAttachment attachment : message.getAttachments()) {
                                if (attachment.getTitle().contains(C.TITLE_VALUE_FILE) && !attachment.getTitleUrl().isEmpty()) {
                                    filePath = attachment.getTitleUrl();
                                }
                            }
                        }
                        if (filePath == null) {
                            sendMessage(mainHandler, message.getId(), message.getRoomId(), message.getMessage(), listener, roomName);
                        } else {
                            requestFileSpaceAndUpload(message.getRoomId(), filePath, fileListener);
                        }
                    }
                }
            }
        });

    }

    public void sendMessage(final Handler mainHandler, String messageId, final String roomId, final String message, final ISendMessagesCallback listener, final String roomName) {
        C.L("trying to send message");
        try {
            if (messageId == null) {
                messageId = UUID.randomUUID().toString();
            }
            final String messageID = messageId;
            final JSONObject messageJsonObject = new JSONObject()
                    .put(C.JSON_FIELD_ID, messageId)
                    .put(C.JSON_FIELD_ROOM_ID, roomId)
                    .put(C.JSON_FIELD_MESSAGE, message)
                    .put(C.JSON_FIELD_POS_ON_THE_LIST, connectionListPosition)
                    .put(C.JSON_FIELD_SYNCSTATE, SyncState.SYNCING)
                    .put(C.JSON_FIELD_USER_SHORT, new JSONObject().put(C.JSON_FIELD_USERNAME, user.getUsername()))
                    .put(C.JSON_FIELD_TIMESTAMP, System.currentTimeMillis());
            final String hostUrl = getHost().getHostRocketChatApiUrl();
            RealmHelper.getInstance().addMessageFromJson(messageJsonObject);
            listener.onMessageStateUpdated();
            Task.callInBackground(new Callable<Object>() {
                @Override
                public Object call() throws Exception {
                    CustomRequests.sendMessage(hostUrl, message, roomName, new CustomRequests.SimpleHttpResponseListener() {
                        @Override
                        public void onSuccess() {
                            mainHandler.post(new Runnable() {
                                @Override
                                public void run() {
                                    Task.callInBackground(new Callable<Object>() {
                                        @Override
                                        public Object call() throws Exception {
                                            C.L("message saved?");
                                            messageJsonObject.remove(C.JSON_FIELD_SYNCSTATE);
                                            messageJsonObject.remove(C.JSON_FIELD_TIMESTAMP);
                                            listener.onMessageStateUpdated();
                                            ddpClient.rpc(C.RPC_SEND_MESSAGE, new JSONArray().put(messageJsonObject), UUID.randomUUID().toString(), C.TIMEOUT_MS).continueWith(new Continuation<DDPClientCallback.RPC, Object>() {
                                                @Override
                                                public Object then(Task<DDPClientCallback.RPC> task2) throws Exception {
                                                    C.L("message Sent returned" + task2.getResult().result);
                                                    handler.post(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            RealmHelper.getInstance().updateMessageState(connectionListPosition, messageID, SyncState.SYNCED);
                                                            listener.onMessageStateUpdated();
                                                        }
                                                    });
                                                    return null;
                                                }
                                            }).continueWith(getBasicErrorContinuationObject(new IBaseErrorCallback() {
                                                @Override
                                                public void onErrorDuringConnection() {
                                                    handler.post(new Runnable() {
                                                        @Override
                                                        public void run() {
                                                            RealmHelper.getInstance().updateMessageState(connectionListPosition, messageID, SyncState.FAILED);
                                                            listener.onErrorDuringConnection();
                                                        }
                                                    });
                                                }
                                            }));
                                            return null;
                                        }
                                    });
                                }
                            });
                        }

                        @Override
                        public void onFail() {
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    RealmHelper.getInstance().updateMessageState(connectionListPosition, messageID, SyncState.FAILED);
                                    listener.onErrorDuringConnection();
                                }
                            });
                        }
                    });
                    return null;
                }
            });
        } catch (JSONException je) {
            je.printStackTrace();
            listener.onErrorDuringConnection();
        }
    }

    public void requestFileSpaceAndUpload(final String roomId, final String filePath, final ISendFileCallback listener) {
        C.L("trying to send file");
        try {
            final JSONObject messageJsonObject = new JSONObject()
                    .put(C.JSON_FIELD_ID, filePath)
                    .put(C.JSON_FIELD_ROOM_ID, roomId)
                    .put(C.JSON_FIELD_MESSAGE, "")
                    .put(C.JSON_FIELD_POS_ON_THE_LIST, connectionListPosition)
                    .put(C.JSON_FIELD_SYNCSTATE, SyncState.SYNCING)
                    .put(C.JSON_FIELD_USER_SHORT, new JSONObject().put(C.JSON_FIELD_USERNAME, user.getUsername()))
                    .put(C.JSON_FIELD_ATTACHMENTS, new JSONArray().put(new JSONObject().put(C.JSON_FIELD_TITLE, C.TITLE_VALUE_FILE).put(C.JSON_FIELD_TITLE_URL, filePath)))
                    .put(C.JSON_FIELD_TIMESTAMP, System.currentTimeMillis());
            RealmHelper.getInstance().addMessageFromJson(messageJsonObject);
            listener.onImageAddedToDatabase();
            C.L("FILEUPLOAD #1");
            Task.callInBackground(new Callable<Object>() {
                @Override
                public Object call() throws Exception {
                    C.L("FILEUPLOAD #2.0");
                    String[] pathSegments = filePath.split("/");
                    final String fileName = pathSegments[pathSegments.length - 1];
                    final String fileMimeType = ChatUtilities.getMimeType(filePath);
                    final File file = new File(filePath);
                    final long fileSize = file.length();
                    JSONObject fileInfoJson = new JSONObject();
                    fileInfoJson.put(C.JSON_FIELD_NAME, fileName);
                    fileInfoJson.put(C.JSON_FIELD_SIZE, fileSize);
                    fileInfoJson.put(C.JSON_FIELD_TYPE, fileMimeType);
                    JSONObject roomIdJson = new JSONObject();
                    roomIdJson.put(C.JSON_FIELD_ROOM_ID, roomId);
                    JSONArray array = new JSONArray();
                    array.put("rocketchat-uploads");
                    array.put(fileInfoJson);
                    array.put(roomIdJson);
                    C.L("trying to send file 1:" + array.toString());
                    C.L("FILEUPLOAD #2.1");
                    if (CommunicationManager.isOnline()) {
                        ddpClient.rpc(C.RPC_UPLOAD_REQUEST, array, UUID.randomUUID().toString(), C.TIMEOUT_MS).continueWith(new Continuation<DDPClientCallback.RPC, Object>() {
                            @Override
                            public Object then(Task<DDPClientCallback.RPC> task2) throws Exception {
                                if (!task2.isFaulted()) {
                                    C.L("FILEUPLOAD #3.1 upload request returned " + task2.getResult().result);
                                    parseResultAndUpload(file, roomId, task2.getResult().result, fileName, filePath, fileSize, fileMimeType, listener);
                                } else {
                                    C.L("FILEUPLOAD #3.12");
                                    listener.onFileTooBigError(filePath);
                                }
                                return null;
                            }
                        }).continueWith(new Continuation<Object, Object>() {
                            @Override
                            public Object then(Task<Object> task) throws Exception {
                                if (task.getError() != null) {
                                    listener.onErrorDuringUpload(filePath);
                                }
                                return null;
                            }
                        });
                    } else {
                        listener.onErrorDuringUpload(filePath);
                    }
                    return null;
                }
            });
        } catch (JSONException e) {
            C.L("FILEUPLOAD #1.1");
            e.printStackTrace();
            listener.onErrorDuringUpload(filePath);
        }
    }

    public void sendFileMessage(final String storageType, final String roomId, final String downloadUrl, final long fileSize, final String mimeType, final String fileName, final String filePath, final ISendFileCallback listener) {
        C.L("trying to send file");
        Task.callInBackground(new Callable<Object>() {
            @Override
            public Object call() throws Exception {
                C.L("FILEUPLOAD #5.0");
                String id = Uri.parse(downloadUrl).getLastPathSegment();
                String randomUUID = UUID.randomUUID().toString();
                C.L("ID=" + id);
                C.L("RANDOM_UUID=" + randomUUID);
                JSONObject fileJson = new JSONObject()
                        .put("_id", id)
                        .put("type", mimeType)
                        .put("size", fileSize)
                        .put("name", fileName)
                        .put("url", downloadUrl);
                JSONArray array = new JSONArray();
                array.put(roomId);
                array.put(storageType);
                array.put(fileJson);
                C.L("FILEUPLOAD #5.1");
                C.L("trying to send file 1:" + array.toString());
                ddpClient.rpc(C.RPC_SEND_FILE_MESSAGE, array, randomUUID, C.TIMEOUT_MS).continueWith(new Continuation<DDPClientCallback.RPC, Object>() {
                    @Override
                    public Object then(Task<DDPClientCallback.RPC> task2) throws Exception {
                        C.L("FILEUPLOAD #5.2");
                        if (!task2.isFaulted()) {
                            C.L("upload request returned " + task2.getResult().result);
                            listener.onFileSent(fileName, filePath);
                        } else {
                            listener.onErrorDuringUpload(filePath);
                        }
                        return null;
                    }
                });
                return null;
            }
        });
    }

    private void parseResultAndUpload(final File file, final String roomId, String result, final String filename, final String filePath, final long filesize, final String mimeType, final ISendFileCallback listener) {
        try {
            C.L("FILEUPLOAD #4.0");

            JSONObject info = new JSONObject(result);
            String uploadUrl = info.getString("upload");
            final String downloadUrl = info.getString("download");
            JSONArray postDataList = info.getJSONArray("postData");
            MultipartBody.Builder bodyBuilder = new MultipartBody.Builder().setType(MultipartBody.FORM);
            for (int i = 0; i < postDataList.length(); i++) {
                JSONObject postData = postDataList.getJSONObject(i);
                bodyBuilder.addFormDataPart(postData.getString("name"), postData.getString("value"));
            }
            C.L("FILEUPLOAD #4.1");
            bodyBuilder.addFormDataPart("file", filename,
                    new RequestBody() {
                        private long numBytes = 0;

                        @Override
                        public MediaType contentType() {
                            return MediaType.parse(mimeType);
                        }

                        @Override
                        public long contentLength() throws IOException {
                            return filesize;
                        }

                        @Override
                        public void writeTo(BufferedSink sink) throws IOException {
                            try {
                                C.L("FILEUPLOAD #4.2");
                                Source source = Okio.source(file);
                                long readBytes;
                                while ((readBytes = source.read(sink.buffer(), 8192)) > 0) {
                                    numBytes += readBytes;
                                }
                                sendFileMessage("s3", roomId, downloadUrl, filesize, mimeType, filename, filePath, listener);
                            } catch (Exception e) {
                                e.printStackTrace();
                                listener.onErrorDuringUpload(filePath);
                            }
                        }
                    });
            C.L("FILEUPLOAD #4.3");
            Request request = new Request.Builder()
                    .url(uploadUrl)
                    .post(bodyBuilder.build())
                    .build();
            Response response = OkHttpHelper.getClientForUploadFile().newCall(request).execute();
        } catch (JSONException | IOException e) {
            e.printStackTrace();
            C.L("FILEUPLOAD #4.4");
            listener.onErrorDuringUpload(filePath);
        }
    }

    public void createAChannelIfDoesNotExists(final IChannelCreatedCallback listener) {
        getRooms(ddpClient, new IGetRoomsCallback() {
            @Override
            public void onRoomsReady(RoomSubscription[] rooms) {
                C.L("create a channel rooms ready");
                String roomId = null;
                for (RoomSubscription room : rooms) {
                    if (room.getName().equals(user.getChannelName())) {
                        C.L("create a channel room found");
                        roomId = room.getRoomId();
                    }
                }
                if (roomId != null) {
                    final String finalRoomId = roomId;
                    C.L("create a channel trying to save roomId");
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            C.L("create a channel trying to save roomId 2");
                            RealmHelper.getInstance().executeCustomTransaction(new Realm.Transaction() {
                                @Override
                                public void execute(Realm realm) {
                                    host.setRoomId(finalRoomId);
                                    realm.copyToRealmOrUpdate(host);
                                    listener.onChannelCreated();
                                }
                            });
                        }
                    });
                } else {
                    C.L("create a channel no channels found trying to create");
                    createAChannel(user.getChannelName(), new IChannelCreatedCallback() {
                        @Override
                        public void onChannelCreated() {
                            listener.onChannelCreated();
                        }

                        @Override
                        public void onErrorDuringConnection() {
                            listener.onErrorDuringConnection();
                        }
                    });
                }
            }

            @Override
            public void onErrorDuringConnection() {
                listener.onErrorDuringConnection();
            }
        });
    }

    public void sendGCMStuff(final Context context, final IChannelCreatedCallback listener) {
        C.L("trying to sendGCMStuff");
        Task.callInBackground(new Callable<Object>() {
            @Override
            public Object call() throws Exception {
                String userId = ConnectionManager.getInstance().getUser().getId();
                String gcmToken = FirebaseInstanceId.getInstance().getToken();
                String pushId = GCMHelper.getOrCreatePushId(context);
                final JSONArray jsonArray = new JSONArray().put(new JSONObject()
                        .put("id", pushId)
                        .put("appName", "main")
                        .put("userId", userId != null ? userId : JSONObject.NULL)
                        .put("metadata", new JSONObject())
                        .put("token", new JSONObject().put("gcm", gcmToken)));
                C.L("sendGCM with json" + jsonArray);
                ddpClient.rpc(C.RPC_PUSH_UPDATE, jsonArray, UUID.randomUUID().toString(), C.TIMEOUT_MS).continueWith(new Continuation<DDPClientCallback.RPC, Object>() {
                    @Override
                    public Object then(Task<DDPClientCallback.RPC> task2) throws Exception {
                        C.L("sendGCM returned" + task2.getResult().result);
                        return null;
                    }
                }).continueWith(getBasicErrorContinuationObject(listener));
                return null;
            }
        });
    }

    private void createAChannel(final String channelName,
                                final IChannelCreatedCallback listener) {
        C.L("trying to createAChannel");
        Task.callInBackground(new Callable<Object>() {
            @Override
            public Object call() throws Exception {
                final JSONArray jsonArray = new JSONArray()
                        .put(channelName)
                        .put(new JSONArray())
                        .put(false);
                C.L("channel create with json" + jsonArray);
                ddpClient.rpc(C.RPC_CREATE_CHANNEL, jsonArray, UUID.randomUUID().toString(), C.TIMEOUT_MS).continueWith(new Continuation<DDPClientCallback.RPC, Object>() {
                    @Override
                    public Object then(Task<DDPClientCallback.RPC> task2) throws Exception {
                        C.L("channel create returned" + task2.getResult().result);
                        final RoomId roomId = new Gson().fromJson(task2.getResult().result, RoomId.class);
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                RealmHelper.getInstance().executeCustomTransaction(new Realm.Transaction() {
                                    @Override
                                    public void execute(Realm realm) {
                                        host.setRoomId(roomId.getRid());
                                        realm.copyToRealmOrUpdate(host);
                                        listener.onChannelCreated();
                                    }
                                });
                            }
                        });
                        return null;
                    }
                }).continueWith(getBasicErrorContinuationObject(listener));
                return null;
            }
        });
    }

    private void loginWithPass(DDPClient client,
                               final IConnectAndLoginCallback connectAndLoginCallback) {
        try {
            JSONObject param = new JSONObject();
            if (Patterns.EMAIL_ADDRESS.matcher(user.getEmail()).matches()) {
                param.put(C.JSON_FIELD_USER, new JSONObject().put(C.JSON_FIELD_EMAIL, user.getEmail()));
            } else {
                param.put(C.JSON_FIELD_USER, new JSONObject().put(C.JSON_FIELD_USERNAME, user.getUsername()));
            }
            param.put(C.JSON_FIELD_PASSWORD, new JSONObject()
                    .put(C.JSON_FIELD_DIGEST, user.getPassword())
                    .put(C.JSON_FIELD_ALGORITHM, C.JSON_FIELD_SHA_256));
            JSONArray jArray = new JSONArray();
            jArray.put(param);
            C.L("log in with json = " + jArray.toString());
            client.rpc(C.RPC_LOGIN, jArray, sessionUUID, C.TIMEOUT_MS).continueWith(new Continuation<DDPClientCallback.RPC, Object>() {
                @Override
                public Object then(Task<DDPClientCallback.RPC> task) throws Exception {
                    C.L("logged in + " + task.getResult().result);
                    checkLoginResultAndParseToken(task.getResult().result, connectAndLoginCallback);
                    return null;
                }
            }).continueWith(getBasicErrorContinuationObject(connectAndLoginCallback));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public Host getHost() {
        return host;
    }

    int getConnectionListPosition() {
        return connectionListPosition;
    }

    void setConnectionListPosition(int connectionListPosition) {
        this.connectionListPosition = connectionListPosition;
    }

    interface IBaseErrorCallback {
        void onErrorDuringConnection();
    }

    interface IConnectAndLoginCallback extends IBaseErrorCallback {
        void onConnectedAndLoggedIn();

        void onNoUsername();
    }

    public interface ISendFileCallback {
        void onFileSent(String name, String filePath);

        void onImageAddedToDatabase();

        void onFileTooBigError(String filePath);

        void onErrorDuringUpload(String filePath);
    }

    public interface IRegisterCallback extends IBaseErrorCallback {
        void onRegistered();
    }

    public interface IResetPasswordCallback extends IBaseErrorCallback {
        void onPasswordReset();
    }

    public interface IGetMessagesCallback extends IBaseErrorCallback {
        void onMessagesReady();
    }

    public interface IGetRoomsCallback extends IBaseErrorCallback {
        void onRoomsReady(RoomSubscription rooms[]);
    }

    public interface ISendMessagesCallback extends IBaseErrorCallback {
        void onMessageStateUpdated();
    }

    public interface IChannelCreatedCallback extends IBaseErrorCallback {
        void onChannelCreated();
    }

    public interface IConnectLoginAndSetUsernameCallback extends IBaseErrorCallback {
        void onUsernameSet();

        void onUsernameTaken();
    }

    private interface IReconnectStateChanged {
        void connected();

        void notConnected();
    }
}
