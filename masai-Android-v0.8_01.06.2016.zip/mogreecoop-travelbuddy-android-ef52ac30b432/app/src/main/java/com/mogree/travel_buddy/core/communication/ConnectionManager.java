package com.mogree.travel_buddy.core.communication;

import com.google.gson.Gson;
import com.mogree.travel_buddy.core.helper.C;
import com.mogree.travel_buddy.core.helper.PrefsHelper;
import com.mogree.travel_buddy.core.helper.RealmHelper;
import com.mogree.travel_buddy.core.model.Host;
import com.mogree.travel_buddy.core.model.User;

import java.util.ArrayList;
import java.util.List;

import io.realm.RealmChangeListener;
import io.realm.RealmResults;

/**
 * Created by Semko on 2016-12-02.
 */

public class ConnectionManager {
    private static ConnectionManager instance;
    private List<HostConnection> hostConnections = new ArrayList<>();
    private User user;
    private List<Host> hostList = new ArrayList<>(); // Array will not exists (with dependency of array index) if the logic of logging in to more than one server will be clear
    private String gcmToken;

    private RealmChangeListener<RealmResults<Host>> hostConnectionListChangeListener = new RealmChangeListener<RealmResults<Host>>() {
        @Override
        public void onChange(RealmResults<Host> element) {

        }
    };

    protected ConnectionManager() {
        retrieveData();
        loadHostConnectionsFromDB();
        demoHostList();
    }

    public static ConnectionManager getInstance() {
        if (instance == null) {
            instance = new ConnectionManager();
        }
        return instance;
    }

    public int hasHost(int pos) {
        if (hostList.size() > pos) {
            String hostToAddUrl = hostList.get(pos).getHostUrl();
            for (HostConnection connection : hostConnections) {
                if (connection.getHost().getHostUrl().equals(hostToAddUrl)) {
                    return connection.getConnectionListPosition();
                }
            }
        }
        return -1;
    }

    private void loadHostConnectionsFromDB() {
        for (Host host : RealmHelper.getInstance().getHostConnectionListListener(hostConnectionListChangeListener)) {
            addHostToList(host);
        }
    }

    public List<HostConnection> getHostConnectionList() {
        return hostConnections;
    }

    public HostConnection getHostConnectionForPos(int pos) {
        if (pos < hostConnections.size()) {
            return hostConnections.get(pos);
        }
        return null;
    }

    public List<Host> getHostList() {
        return hostList;
    }

    private void retrieveData() {
        if (PrefsHelper.getInstance().contains(C.PREFERENCES_KEY_USER)) {
            user = new Gson().fromJson(PrefsHelper.getInstance().getString(C.PREFERENCES_KEY_USER), User.class);
            C.L("user retrieved + " + user.getEmail() + ", " + user.getPassword() + ", " + user.getUsername());
        }
    }

    private void demoHostList() {
//        Host demoHost = new Host();
//        demoHost.setHostUrl("wss://demo.rocket.chat/websocket");
//        demoHost.setHostRocketChatApiUrl("https://demo.rocket.chat/");
//        demoHost.setHumanName("Demo Rocket Chat Server");
        Host reisebuddy = new Host();
        reisebuddy.setHostUrl("http://demo.masai.solutions:2999/websocket");
        reisebuddy.setHostRocketChatApiUrl("http://demo.masai.solutions:2999/");
        reisebuddy.setHumanName("DB Concierge");
//        Host shmu = new Host();
//        shmu.setHostUrl("http://10.11.22.53:3000/websocket");
//        shmu.setHostRocketChatApiUrl("http://10.11.22.53:3000/");
//        shmu.setHumanName("Super Hiper Mega Ultra...");
//        Host killer = new Host();
//        killer.setHostUrl("http://10.11.22.54:3000/websocket");
//        killer.setHostRocketChatApiUrl("http://10.11.22.54:3000/");
//        killer.setHumanName("REVRES");
//        Host theLocator = new Host();
//        theLocator.setHostUrl("http://demo.masai.solutions:3000/websocket");
//        theLocator.setHostRocketChatApiUrl("http://demo.masai.solutions:3000/");
//        theLocator.setHumanName("THE LOCATOR");
//        hostList.add(demoHost);
        hostList.add(reisebuddy);
//        hostList.add(shmu);
//        hostList.add(killer);
//        hostList.add(theLocator);
    }

    public void addConnection(int position, final IConnectListener listener) {
        Host realmHost = RealmHelper.getInstance().addHost(hostList.get(position));
        final int connectionPos = addHostToList(realmHost) - 1;
        connectToAll(new IConnectListener() {
            @Override
            public void onNoUsername(int pos) {
                if (connectionPos == pos) {
                    listener.onNoUsername(pos);
                }
            }

            @Override
            public void onConnected(int pos) {
                if (connectionPos == pos) {
                    listener.onConnected(connectionPos);
                }
            }

            @Override
            public void onError(int pos) {
                if (connectionPos == pos) {
                    listener.onError(connectionPos);
                }
            }
        });
    }

    public void removeConnection(int position) {
        if (hostConnections.size() > position) {
            RealmHelper.getInstance().removeHost(hostConnections.get(position).getHost().getId());
            hostConnections.remove(position);
        }
    }

    public void connectToAll(IConnectListener listener) {
        for (int co0 = 0; co0 < hostConnections.size(); ++co0) {
            connectTo(co0, listener);
        }
    }

    public void connectTo(final int pos, final IConnectListener listener) {
        if (pos < hostConnections.size()) {
            HostConnection connection = hostConnections.get(pos);
            connection.connectAndLogin(new HostConnection.IConnectAndLoginCallback() {
                @Override
                public void onConnectedAndLoggedIn() {
                    listener.onConnected(pos);
                }

                @Override
                public void onNoUsername() {
                    listener.onNoUsername(pos);
                }

                @Override
                public void onErrorDuringConnection() {
                    listener.onError(pos);
                }
            });
        }
    }

    private int addHostToList(Host host) {
        final HostConnection connection = new HostConnection(host, user);
        connection.setConnectionListPosition(hostConnections.size());
        hostConnections.add(connection);
        return hostConnections.size();
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
        String userJ = new Gson().toJson(user);
        for (HostConnection hostConnection : hostConnections) {
            hostConnection.setUser(user);
        }
        PrefsHelper.getInstance().setString(C.PREFERENCES_KEY_USER, userJ);
    }

    public String getGcmToken() {
        return gcmToken;
    }

    public void setGcmToken(String gcmToken) {
        this.gcmToken = gcmToken;
    }

    public interface IConnectListener {
        void onNoUsername(int pos);

        void onConnected(int pos);

        void onError(int pos);
    }
}
