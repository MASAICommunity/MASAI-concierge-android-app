package com.mogree.travel_buddy;

import android.support.multidex.MultiDexApplication;

/**
 * Created by Semko on 2017-01-12.
 */

public class App extends MultiDexApplication {
}
