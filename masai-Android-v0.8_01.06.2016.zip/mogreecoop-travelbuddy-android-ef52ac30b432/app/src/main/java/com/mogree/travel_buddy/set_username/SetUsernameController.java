package com.mogree.travel_buddy.set_username;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.chat.ChatController;
import com.mogree.travel_buddy.core.communication.ConnectionManager;
import com.mogree.travel_buddy.core.communication.HostConnection;
import com.mogree.travel_buddy.core.helper.C;

import java.util.concurrent.Callable;

import bolts.Task;

public class SetUsernameController extends AppCompatActivity implements SetUsernameView.UsernameSetViewListener {
    private SetUsernameView view;
    private int connectionListPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_username);
        connectionListPosition = getIntent().getIntExtra(C.EXTRA_HOST_CONNECTION_POSITION, 0);
        view = new SetUsernameView(findViewById(android.R.id.content), this, this);
        if (ConnectionManager.getInstance().getUser().getFullName() != null && !ConnectionManager.getInstance().getUser().getFullName().isEmpty()) {
            C.L("Username setting");
            setUsername(ConnectionManager.getInstance().getUser().getFullName());
        } else {
            C.L("Username NOT setting");
        }
    }

    @Override
    public void onBackArrowPressed() {
        onBackPressed();
    }

    private void setUsername(String username) {
        view.showProgress();
        ConnectionManager.getInstance().getHostConnectionForPos(connectionListPosition).setUsername(username, new HostConnection.IConnectLoginAndSetUsernameCallback() {
            @Override
            public void onUsernameSet() {
                C.L("Username set");
                createChannel();
                view.hideProgress();
            }

            @Override
            public void onUsernameTaken() {
                C.L("Username taken");
                view.showUsernameSetErrorInfo();
                view.hideProgress();
            }

            @Override
            public void onErrorDuringConnection() {
                C.L("Username con error");
                view.showUsernameSetErrorInfo();
                view.hideProgress();
            }
        });
    }

    @Override
    public void onUsernameSet(String username) {
        setUsername(username);
    }

    private void createChannel() {
        ConnectionManager.getInstance().getHostConnectionForPos(connectionListPosition).createAChannelIfDoesNotExists(new HostConnection.IChannelCreatedCallback() {
            @Override
            public void onChannelCreated() {
                String roomId = ConnectionManager.getInstance().getHostConnectionForPos(connectionListPosition).getHost().getRoomId();
                C.L("Channel created or found successfully with roomid = " + roomId);
                loadMessages(roomId, connectionListPosition);
            }

            @Override
            public void onErrorDuringConnection() {
                C.L("Channel creation failed");
                view.hideProgress();
            }
        });
    }

    private void loadMessages(final String roomId, final int pos) {
        Task.callInBackground(new Callable<Object>() {
            @Override
            public Object call() throws Exception {
                ConnectionManager.getInstance().getHostConnectionForPos(pos).loadMessagesFromWhileIWasAway(roomId, new HostConnection.IGetMessagesCallback() {
                    @Override
                    public void onMessagesReady() {
                        startChat(pos);
                        view.hideProgress();
                    }

                    @Override
                    public void onErrorDuringConnection() {
                        startChat(pos);
                        view.hideProgress();
                    }
                });
                return null;
            }
        });
    }

    private void startChat(int pos) {
        Intent intent = new Intent(this, ChatController.class);
        intent.putExtra(C.EXTRA_HOST_CONNECTION_POSITION, pos);
        finish();
        startActivity(intent);
    }
}