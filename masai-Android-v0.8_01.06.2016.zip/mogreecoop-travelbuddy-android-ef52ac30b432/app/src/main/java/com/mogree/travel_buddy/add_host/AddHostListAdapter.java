package com.mogree.travel_buddy.add_host;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.model.Host;

import java.util.List;

/**
 * Created by Semko on 2016-12-02.
 */

class AddHostListAdapter extends ArrayAdapter<Host> {

    AddHostListAdapter(Context context, List<Host> hostList) {
        super(context, R.layout.item_host_list, hostList);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.item_host_list, parent, false);
            viewHolder.tvName = (TextView) convertView.findViewById(R.id.host_list_name);
            viewHolder.tvLogoName = (TextView) convertView.findViewById(R.id.host_list_name_logo_text);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.tvName.setText(getItem(position).getHumanName());
        viewHolder.tvLogoName.setText(getItem(position).getHumanName().substring(0, 2));
        return convertView;
    }

    private static class ViewHolder {
        TextView tvName;
        TextView tvLogoName;
    }
}
