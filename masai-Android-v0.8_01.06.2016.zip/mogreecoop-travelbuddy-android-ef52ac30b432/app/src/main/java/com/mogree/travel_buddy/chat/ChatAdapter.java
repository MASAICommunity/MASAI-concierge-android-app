package com.mogree.travel_buddy.chat;

import android.content.Context;
import android.support.annotation.NonNull;
import android.text.Spannable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.DrawableRequestBuilder;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.model.GlideUrl;
import com.bumptech.glide.load.model.LazyHeaders;
import com.bumptech.glide.load.resource.drawable.GlideDrawable;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;
import com.google.gson.Gson;
import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.communication.ConnectionManager;
import com.mogree.travel_buddy.core.helper.C;
import com.mogree.travel_buddy.core.helper.RealmHelper;
import com.mogree.travel_buddy.core.helper.TimeHelper;
import com.mogree.travel_buddy.core.model.GooglePlace;
import com.mogree.travel_buddy.core.model.GooglePlacesWrapper;
import com.mogree.travel_buddy.core.model.Message;
import com.mogree.travel_buddy.core.model.MessageAttachment;
import com.mogree.travel_buddy.core.model.MessageType;
import com.mogree.travel_buddy.core.model.SyncState;
import com.mogree.travel_buddy.core.model.Train;
import com.none.emojioneandroidlibrary.Emojione;

import org.lucasr.twowayview.TwoWayView;

import java.io.File;
import java.util.Calendar;

public class ChatAdapter extends ArrayAdapter<Message> {
    private int connectionListPosition;
    private OnChatAdapterListener listener;
    private static String temporaryImagePath = null;
    private static String temporaryImageName = null;
    private String userId;
    private String token;

    public ChatAdapter(Context context, int connectionListPosition, OnChatAdapterListener listener) {
        super(context, R.layout.item_list_chat);
        this.connectionListPosition = connectionListPosition;
        this.listener = listener;
    }

    public void setTemporaryImagePath(String imagePath, String imageName) {
        temporaryImagePath = imagePath;
        temporaryImageName = imageName;
    }

    public static Train[] getTrains(String message) {
        try {
            return new Gson().fromJson(message, Train[].class);
        } catch (Exception e) {
            return null;
        }
    }

    public static GooglePlace[] getGooglePlaces(String message) {
        GooglePlacesWrapper wrapper;
        try {
            wrapper = new Gson().fromJson(message, GooglePlacesWrapper.class);
        } catch (Exception e) {
            return null;
        }
        if (wrapper != null) {
            return wrapper.getResults();
        }
        return null;
    }

    @Override
    public int getCount() {
        return RealmHelper.getInstance().getMessages(connectionListPosition).size();
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Message message = RealmHelper.getInstance().getMessages(connectionListPosition).get(position);
        String messageString = message.getMessage();
        convertView = null;
        if (messageString.startsWith("{") || messageString.startsWith("[")) {
            Train[] trains = getTrains(messageString);
            if (trains != null && trains.length > 0) {
                convertView = loadTrainCards(trains, convertView, parent, position);
            } else {
                GooglePlace[] places = getGooglePlaces(messageString);
                if (places != null && places.length > 0) {
                    convertView = loadGoogleCards(places, convertView, parent, position);
                }
            }
        }
        String imageUrl = null;
        String imageLocalPath = null;
        if (message.getAttachments() != null && message.getAttachments().length > 0) {
            for (MessageAttachment attachment : message.getAttachments()) {
                if (attachment.getImageUrl() != null && !attachment.getImageUrl().isEmpty()) {
                    imageUrl = attachment.getImageUrl();
                }
                if (attachment.getTitle().equals(C.TITLE_VALUE_FILE) && !attachment.getTitleUrl().isEmpty()) {
                    imageLocalPath = attachment.getTitleUrl();
                }
            }
        }
        if (convertView == null) {
            convertView = loadStandardMessage(imageLocalPath, imageUrl, message, convertView, parent, position);
        }
        return convertView;
    }

    private View loadTrainCards(Train[] trains, View convertView, ViewGroup parent, int position) {
        LayoutInflater inflater = LayoutInflater.from(getContext());
        convertView = inflater.inflate(R.layout.item_horizontal_sublist, parent, false);
        TwoWayView twoWayView = (TwoWayView) convertView.findViewById(R.id.horizontal_sublist);
        TrainAdapter trainAdapter = new TrainAdapter(getContext(), trains);
        twoWayView.setAdapter(trainAdapter);
        return convertView;
    }

    private void loadFromFile(String path, ImageView imageView, RequestListener requestListener) {
        File file = new File(path);
        try {
            Glide.with(getContext()).load(file).error(R.drawable.add_message).listener(requestListener).into(imageView);
        } catch (IllegalArgumentException iae) {
            iae.printStackTrace();
        }
    }

    private void downloadImage(String imageUrl, ViewHolder viewHolder, boolean animate) {
        if (imageUrl.startsWith("/")) {
            imageUrl = imageUrl.substring(1, imageUrl.length());
        }
        String url = ConnectionManager.getInstance().getHostConnectionForPos(connectionListPosition).getHost().getHostRocketChatApiUrl().concat(imageUrl);
        GlideUrl glideUrl = new GlideUrl(url, new LazyHeaders.Builder()
                .addHeader("Cookie", "rc_uid=" + userId + ";rc_token=" + token)
                .build());
        DrawableRequestBuilder<GlideUrl> drawableRequestBuilder;
        try {
            if (!animate) {
                drawableRequestBuilder = Glide.with(getContext()).load(glideUrl).error(R.drawable.add_message).dontAnimate();
            } else {
                drawableRequestBuilder = Glide.with(getContext()).load(glideUrl).error(R.drawable.add_message);
            }
            drawableRequestBuilder.listener(new RequestListener<GlideUrl, GlideDrawable>() {
                @Override
                public boolean onException(Exception e, GlideUrl model, Target<GlideDrawable> target, boolean isFirstResource) {
                    temporaryImagePath = null;
                    return false;
                }

                @Override
                public boolean onResourceReady(GlideDrawable resource, GlideUrl model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
                    listener.onImageLoaded();
                    temporaryImagePath = null;
                    return false;
                }
            }).into(viewHolder.ivMessageImage);
        } catch (IllegalArgumentException iae) {
            iae.printStackTrace();
        }
    }

    private boolean loadImageIntoImageView(String localImagePath, Message message, final String imageUrl, final ViewHolder viewHolder) {
        if ((imageUrl != null && !imageUrl.isEmpty()) || (localImagePath != null && !localImagePath.isEmpty())) {
            viewHolder.rlMyMessage.setVisibility(View.GONE);
            viewHolder.llTheirMessage.setVisibility(View.GONE);
            viewHolder.rlMessageImage.setVisibility(View.VISIBLE);
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(message.getTimeStamp());
            String date = TimeHelper.getHumanReadableDate(getContext(), calendar);
            String userSharedPhotoText = String.format(getContext().getString(R.string.user_shared_photo_at), message.getUser().getUsername(), date);
            viewHolder.tvMessageImageText.setText(userSharedPhotoText);
            userId = ConnectionManager.getInstance().getUser().getId();
            setSyncState(viewHolder.ivMessageImageStatus, null, message.getSyncstate());
            token = ConnectionManager.getInstance().getHostConnectionForPos(connectionListPosition).getHost().getToken();
            if (imageUrl == null || imageUrl.isEmpty()) {
                loadFromFile(localImagePath, viewHolder.ivMessageImage, new RequestListener() {
                    @Override
                    public boolean onException(Exception e, Object model, Target target, boolean isFirstResource) {
                        return false;
                    }

                    @Override
                    public boolean onResourceReady(Object resource, Object model, Target target, boolean isFromMemoryCache, boolean isFirstResource) {
                        return false;
                    }
                });
            } else if (localImagePath == null || localImagePath.isEmpty()) {
                if (temporaryImagePath != null && imageUrl.contains(temporaryImageName)) {
                    loadFromFile(temporaryImagePath, viewHolder.ivMessageImage, new RequestListener<File, GlideDrawable>() {
                        @Override
                        public boolean onException(Exception e, File model, Target<GlideDrawable> target, boolean isFirstResource) {
                            downloadImage(imageUrl, viewHolder, true);
                            return false;
                        }

                        @Override
                        public boolean onResourceReady(GlideDrawable resource, File model, Target<GlideDrawable> target, boolean isFromMemoryCache, boolean isFirstResource) {
                            downloadImage(imageUrl, viewHolder, false);
                            listener.onImageLoaded();
                            return false;
                        }
                    });
                } else {
                    downloadImage(imageUrl, viewHolder, true);
                }

            }
            return true;
        } else {
            viewHolder.rlMessageImage.setVisibility(View.GONE);
            return false;
        }
    }

    private View loadGoogleCards(GooglePlace[] googlePlaces, View convertView, ViewGroup parent, int position) {
        LayoutInflater inflater = LayoutInflater.from(getContext());
        convertView = inflater.inflate(R.layout.item_horizontal_sublist, parent, false);
        TwoWayView twoWayView = (TwoWayView) convertView.findViewById(R.id.horizontal_sublist);
        GooglePlacesAdapter googlePlacesAdapter = new GooglePlacesAdapter(getContext(), googlePlaces);
        twoWayView.setAdapter(googlePlacesAdapter);
        return convertView;
    }

    private View loadStandardMessage(String localImagePath, String imageUrl, Message message, View convertView, ViewGroup parent, int position) {
        ViewHolder viewHolder;
        if (convertView == null || convertView.getTag() == null) {
            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.item_message, parent, false);
            viewHolder.llTheirMessage = (LinearLayout) convertView.findViewById(R.id.message_item_their_ll);
            viewHolder.rlMyMessage = (RelativeLayout) convertView.findViewById(R.id.message_item_my_rl);
            viewHolder.tvTheirMessageText = (TextView) convertView.findViewById(R.id.message_item_their_message);
            viewHolder.tvMyMessageText = (TextView) convertView.findViewById(R.id.message_item_my_message);
            viewHolder.tvTheirMessageLogoText = (TextView) convertView.findViewById(R.id.message_item_their_logo_text);
            viewHolder.llTheirMessageLogo = (LinearLayout) convertView.findViewById(R.id.message_item_their_logo);
            viewHolder.tvMyMessageStatus = (TextView) convertView.findViewById(R.id.message_item_my_message_state);
            viewHolder.ivMyMessageState = (ImageView) convertView.findViewById(R.id.message_item_my_message_state_ic);
            viewHolder.tvMessageTime = (TextView) convertView.findViewById(R.id.message_item_time);
            viewHolder.tvMyMessageTime = (TextView) convertView.findViewById(R.id.message_item_my_message_time);
            viewHolder.tvTheirMessageTime = (TextView) convertView.findViewById(R.id.message_item_their_message_time);
            viewHolder.tvTheirMessageTime = (TextView) convertView.findViewById(R.id.message_item_their_message_time);
            viewHolder.ivMessageImage = (ImageView) convertView.findViewById(R.id.message_item_image);
            viewHolder.tvMessageImageText = (TextView) convertView.findViewById(R.id.message_item_image_text);
            viewHolder.rlMessageImage = (RelativeLayout) convertView.findViewById(R.id.message_item_image_rl);
            viewHolder.ivMessageImageStatus = (ImageView) convertView.findViewById(R.id.message_item_image_status);
            viewHolder.margin = convertView.findViewById(R.id.message_item_margin_top);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        Message previousMessage = position - 1 >= 0 ? RealmHelper.getInstance().getMessages(connectionListPosition).get(position - 1) : null;
        if (previousMessage == null || !message.hasSameSenderAs(previousMessage)) {
            viewHolder.llTheirMessageLogo.setVisibility(View.VISIBLE);
            viewHolder.margin.setVisibility(View.VISIBLE);
        } else {
            viewHolder.margin.setVisibility(View.GONE);
            viewHolder.llTheirMessageLogo.setVisibility(View.INVISIBLE);
        }
        if (!loadImageIntoImageView(localImagePath, message, imageUrl, viewHolder)) {
            String messageString = message.getMessage();
            if (message.getAttachments() != null) {
                for (MessageAttachment attachment : message.getAttachments()) {
                    if (attachment.getTitle() != null && !attachment.getTitle().isEmpty() && (attachment.getImageType() == null || attachment.getImageType().isEmpty())) {
                        messageString = C.FILE_FOLDER_ICON;
                    }
                }
            }
            boolean isSingleEmoji = Emojione.isOneEmojiWithNoText(messageString);
            if (MessageType.USER_JOINED.getType().equals(message.getType())) {
                messageString = String.format(getContext().getString(R.string.user_joined), messageString);
            }
            Spannable text = getMessageWithEmoji(messageString, isSingleEmoji);
            showMessageTime(viewHolder, message, previousMessage);
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(message.getTimeStamp());
            if (ConnectionManager.getInstance().getUser().getUsername().equals(message.getUser().getUsername())) {
                viewHolder.tvMyMessageText.setText(text);
                if (isSingleEmoji) {
                    viewHolder.tvMyMessageText.setBackground(null);
                } else {
                    viewHolder.tvTheirMessageText.setBackgroundResource(R.drawable.round_bg_flat_blue);
                }
                viewHolder.llTheirMessage.setVisibility(View.GONE);
                viewHolder.rlMyMessage.setVisibility(View.VISIBLE);
                viewHolder.tvMyMessageTime.setVisibility(View.VISIBLE);
                viewHolder.tvTheirMessageTime.setVisibility(View.GONE);
                viewHolder.tvMyMessageTime.setText(TimeHelper.getTimeOfDay(getContext(), calendar));
                setSyncState(viewHolder.ivMyMessageState, viewHolder.tvMyMessageStatus, message.getSyncstate());
            } else {
                viewHolder.tvTheirMessageTime.setVisibility(View.VISIBLE);
                viewHolder.tvMyMessageTime.setVisibility(View.GONE);
                viewHolder.tvTheirMessageTime.setText(TimeHelper.getTimeOfDay(getContext(), calendar));
                viewHolder.tvTheirMessageLogoText.setText(message.getUser().getUsername().substring(0, 2));
                if (isSingleEmoji) {
                    viewHolder.tvTheirMessageText.setBackground(null);
                } else {
                    viewHolder.tvTheirMessageText.setBackgroundResource(R.drawable.round_bg_red);
                }
                viewHolder.tvTheirMessageText.setText(text);
                viewHolder.llTheirMessage.setVisibility(View.VISIBLE);
                viewHolder.rlMyMessage.setVisibility(View.GONE);
            }
        }
        return convertView;
    }

    private Spannable getMessageWithEmoji(String orgText, boolean large) {
        Spannable spannable = Emojione.replaceAll(getContext(), orgText, large);
        return spannable;
    }

    private void showMessageTime(ViewHolder viewHolder, Message message, Message previousMessage) {
        if ((previousMessage == null) || (previousMessage != null && message.getTimeStamp() - previousMessage.getTimeStamp() > C.MIN_TIME_DIFFERENCE)) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(message.getTimeStamp());
            viewHolder.tvMessageTime.setText(TimeHelper.getHumanReadableDate(getContext(), calendar));
            viewHolder.tvMessageTime.setVisibility(View.VISIBLE);
        } else {
            viewHolder.tvMessageTime.setText("");
            viewHolder.tvMessageTime.setVisibility(View.GONE);
        }
    }

    private void setSyncState(ImageView ivState, TextView tvState, int syncstate) {
        String syncMessage = null;
        int marginSS = (int) getContext().getResources().getDimension(R.dimen.margin_ss);
        int marginXS = (int) getContext().getResources().getDimension(R.dimen.margin_xs);
        if (tvState != null) {
            tvState.setVisibility(View.GONE);
        }
        switch (syncstate) {
            case SyncState.NOT_SYNCED:
            case SyncState.SYNCED:
                ivState.setImageResource(R.drawable.ic_message_sent);
                ivState.setPadding(marginXS, marginXS, marginXS, marginXS);
                break;
            case SyncState.SYNCING:
                ivState.setImageResource(R.drawable.ic_message_sending);
                ivState.setPadding(marginXS, marginXS, marginXS, marginXS);
                break;
            case SyncState.FAILED:
                syncMessage = getContext().getString(R.string.sync_failed);
                ivState.setImageResource(R.drawable.ic_message_failed);
                ivState.setPadding(marginSS, marginSS, marginSS, marginSS);
                if (tvState != null) {
                    tvState.setText(syncMessage);
                    tvState.setVisibility(View.VISIBLE);
                }
                break;
        }
    }

    public interface OnChatAdapterListener {
        void onImageLoaded();
    }

    private static class ViewHolder {
        View margin;
        RelativeLayout rlMyMessage;
        TextView tvMyMessageStatus;
        LinearLayout llTheirMessage;
        LinearLayout llTheirMessageLogo;
        TextView tvTheirMessageText;
        TextView tvMyMessageText;
        TextView tvMyMessageTime;
        TextView tvTheirMessageTime;
        RelativeLayout rlMessageImage;
        ImageView ivMessageImage;
        ImageView ivMessageImageStatus;
        TextView tvMessageImageText;
        TextView tvTheirMessageLogoText;
        ImageView ivMyMessageState;
        TextView tvMessageTime;
    }
}
