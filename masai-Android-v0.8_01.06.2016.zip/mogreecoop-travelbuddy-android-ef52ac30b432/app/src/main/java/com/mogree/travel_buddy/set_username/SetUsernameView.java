package com.mogree.travel_buddy.set_username;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.mogree.travel_buddy.R;

public class SetUsernameView {
    private View rootView;
    private UsernameSetViewListener listener;
    private Context context;
    private EditText etUsername;
    private Button btnContinue;
    private ImageView ivBack;
    private ProgressDialog progressDialog;
    private Handler handler;

    SetUsernameView(View rootView, Context context, UsernameSetViewListener listener) {
        this.rootView = rootView;
        this.context = context;
        this.listener = listener;
        handler = new Handler(Looper.getMainLooper());
        initViews();
    }

    private void initViews() {
        progressDialog = new ProgressDialog(context, ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage(rootView.getContext().getString(R.string.loading_data));
        progressDialog.setCanceledOnTouchOutside(false);
        etUsername = (EditText) rootView.findViewById(R.id.et_username);
        btnContinue = (Button) rootView.findViewById(R.id.btn_submit_username);
        ivBack = (ImageView) rootView.findViewById(R.id.username_ala_action_bar_back);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onBackArrowPressed();
            }
        });
        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = etUsername.getText().toString();
                listener.onUsernameSet(username);
            }
        });
    }

    void showUsernameSetErrorInfo() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(context, R.string.set_username_fail, Toast.LENGTH_LONG).show();
            }
        });
    }

    void showProgress() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                progressDialog.show();
            }
        });
    }

    void hideProgress() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                progressDialog.dismiss();
            }
        });
    }

    interface UsernameSetViewListener {
        void onBackArrowPressed();

        void onUsernameSet(String username);
    }
}
