package com.mogree.travel_buddy.profile;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.mogree.travel_buddy.R;

public class ProfileView {
    private View rootView;
    private ProfileViewListener listener;
    private Context context;
    private TextView tvEmail;
    private TextView tvUsername;
    private TextView tvProfileLogoText;
    private EditText etName;
    private EditText etPassword1;
    private EditText etPassword2;
    private Button btnContinue;
    private ImageView ivBack;
    private ProgressDialog progressDialog;
    private Handler handler;

    ProfileView(View rootView, Context context, ProfileViewListener listener) {
        this.rootView = rootView;
        this.context = context;
        this.listener = listener;
        handler = new Handler(Looper.getMainLooper());
        initViews();
    }

    void setUser(final String username, final String email) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (username != null && !username.isEmpty()) {
                    tvUsername.setText(username);
                    tvProfileLogoText.setText(username.substring(0, 2));
                }
                if (email != null) {
                    tvEmail.setText(email);
                }
            }
        });
    }

    private void initViews() {
        progressDialog = new ProgressDialog(context, ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage(rootView.getContext().getString(R.string.loading_data));
        progressDialog.setCanceledOnTouchOutside(false);
        tvProfileLogoText = (TextView) rootView.findViewById(R.id.profile_logo_text);
        tvEmail = (TextView) rootView.findViewById(R.id.profile_email);
        tvUsername = (TextView) rootView.findViewById(R.id.profile_username);
        etName = (EditText) rootView.findViewById(R.id.profile_user_name);
        etPassword1 = (EditText) rootView.findViewById(R.id.profile_user_pass1);
        etPassword2 = (EditText) rootView.findViewById(R.id.profile_user_pass2);
        btnContinue = (Button) rootView.findViewById(R.id.btn_user_update);
        ivBack = (ImageView) rootView.findViewById(R.id.profile_ala_action_bar_back);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onBackArrowPressed();
            }
        });
        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newPass = "";
                String newName = "";
                if (!etPassword1.getText().toString().isEmpty() && !etPassword2.getText().toString().isEmpty()) {
                    if (etPassword1.getText().toString().equals(etPassword2.getText().toString())) {
                        newPass = etPassword1.getText().toString();
                    } else {
                        Toast.makeText(context, R.string.passwords_dont_match, Toast.LENGTH_LONG).show();
                        return;
                    }
                }
                if (!etName.getText().toString().isEmpty()) {
                    newName = etName.getText().toString();
                }
                listener.onUpdate(newName, newPass);
            }
        });
    }

    void showProgress() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                progressDialog.show();
            }
        });
    }

    public void hideProgress() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (progressDialog != null && progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
            }
        });
    }

    interface ProfileViewListener {
        void onBackArrowPressed();

        void onUpdate(String name, String password);
    }
}
