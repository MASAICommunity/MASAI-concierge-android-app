package com.mogree.travel_buddy.chat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.view.WindowManager;
import android.widget.Toast;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.communication.ConnectionManager;
import com.mogree.travel_buddy.core.communication.HostConnection;
import com.mogree.travel_buddy.core.helper.C;
import com.mogree.travel_buddy.core.helper.RealmHelper;
import com.mogree.travel_buddy.core.model.SyncState;

import java.util.concurrent.Callable;

import bolts.Task;

public class ChatController extends AppCompatActivity implements ChatView.ChatViewListener, ChatAdapter.OnChatAdapterListener {
    boolean downloadingOlder = false;
    private ChatAdapter chatAdapter;
    private ChatView view;
    private static String outputFileUri;
    private boolean isActivityVisible = false;
    private String imagePath;

    private enum ShareType {CAMERA_TYPE, IMAGE_TYPE, FILE_TYPE}

    private ShareType shareType = ShareType.CAMERA_TYPE;

    HostConnection.ISendFileCallback filesCallback = new HostConnection.ISendFileCallback() {
        @Override
        public void onFileSent(final String name, final String filePath) {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    chatAdapter.setTemporaryImagePath(filePath, name);
                    view.hideImageLoadingMessage();
                    messageIdToRemoveOnUpdate = filePath;
                }
            });
        }

        @Override
        public void onImageAddedToDatabase() {
            imagePath = null;
            view.updateList(chatAdapter);
            view.scrollToBottom(chatAdapter);
        }

        @Override
        public void onFileTooBigError(final String filePath) {
            C.L("FILEUPLOAD onFileTooBigError");
            handler.post(new Runnable() {
                @Override
                public void run() {
                    RealmHelper.getInstance().updateMessageState(connectionListPosition, filePath, SyncState.FAILED);
                    view.hideImageLoadingMessage();
                    view.showFileTooBigError();
                    view.updateList(chatAdapter);
                }
            });
        }

        @Override
        public void onErrorDuringUpload(final String filePath) {
            C.L("FILEUPLOAD onErrorDuringUpload");
            handler.post(new Runnable() {
                @Override
                public void run() {
                    RealmHelper.getInstance().updateMessageState(connectionListPosition, filePath, SyncState.FAILED);
                    view.hideImageLoadingMessage();
                    Toast.makeText(context, R.string.upload_failed, Toast.LENGTH_LONG).show();
                    view.updateList(chatAdapter);
                }
            });
        }
    };

    HostConnection.ISendMessagesCallback messagesCallback = new HostConnection.ISendMessagesCallback() {
        @Override
        public void onMessageStateUpdated() {
            C.L("message updated");
            view.updateList(chatAdapter);
            view.jumpToBottom(chatAdapter);
        }

        @Override
        public void onErrorDuringConnection() {
            C.L("message error");
            view.updateList(chatAdapter);
        }
    };
    private Context context;
    private int connectionListPosition;
    private Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onResume() {
        super.onResume();
        isActivityVisible = true;
        temporaryRefresh();
    }

    @Override
    protected void onPause() {
        C.L("onPause");
        super.onPause();
        isActivityVisible = false;
    }

    @Override
    protected void onStop() {
        super.onStop();
        C.L("onStop");
        handler.removeCallbacksAndMessages(null);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        view = new ChatView(findViewById(android.R.id.content), this);
        context = this;
        retrievePos();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        view.setTitle(ConnectionManager.getInstance().getHostConnectionForPos(connectionListPosition).getHost().getHumanName());
        chatAdapter = new ChatAdapter(context, connectionListPosition, this);
        view.setChatListAdapter(chatAdapter);
        view.updateList(chatAdapter);
        ConnectionManager.getInstance().getHostConnectionForPos(connectionListPosition).subscribe();
    }

    private void retrievePos() {
        connectionListPosition = getIntent().getIntExtra(C.EXTRA_HOST_CONNECTION_POSITION, 0);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != RESULT_CANCELED) {
            if (requestCode == C.ACTION_IMAGE_SELECTED) {
                final boolean isCamera = ChatUtilities.isImageFromCamera(data);
                Uri selectedImageUri;
                if (outputFileUri != null) {
                    imagePath = outputFileUri;
                    outputFileUri = null;
                } else {
                    imagePath = null;
                    imagePath = ChatUtilities.getPathFromURI(this, data.getData());
                }
                if (imagePath != null) {
                    if (!imagePath.startsWith("http")) {
                        view.showImageLoadingMessage();
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                sendFile(imagePath);
                            }
                        });
                    } else {
                        view.showToastImageNotOffline();
                    }
                } else {
                    view.showToastImageError();
                }
            }
        }
    }

    private void removeLocalImageMessage() {
        if (messageIdToRemoveOnUpdate != null) {
            RealmHelper.getInstance().removeMessageWithId(connectionListPosition, messageIdToRemoveOnUpdate);
            messageIdToRemoveOnUpdate = null;
        }
    }

    private static String messageIdToRemoveOnUpdate = null;

    private void sendFile(final String filePath) {
        final String roomId = ConnectionManager.getInstance().getHostConnectionForPos(connectionListPosition).getHost().getRoomId();
        ConnectionManager.getInstance().getHostConnectionForPos(connectionListPosition).requestFileSpaceAndUpload(roomId, filePath, filesCallback);
    }

    public void temporaryRefresh() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (isActivityVisible) {
                    getMessages();
                }
            }
        }, C.SEC_5);
    }

    private void getMessages() {
        C.L("getMessages");
        final int countBeforeUpdate = chatAdapter.getCount();
        final String roomId = ConnectionManager.getInstance().getHostConnectionForPos(connectionListPosition).getHost().getRoomId();
        Task.callInBackground(new Callable<Object>() {
            @Override
            public Object call() throws Exception {
                ConnectionManager.getInstance().getHostConnectionForPos(connectionListPosition).loadMessagesFromWhileIWasAway(roomId, new HostConnection.IGetMessagesCallback() {
                    @Override
                    public void onErrorDuringConnection() {
                        C.L("ChatController->getMessages->onErrorDuringConnection!");
                        tryConnecting();
                        view.showConnectionError();
                    }

                    @Override
                    public void onMessagesReady() {
                        int countAfterUpdate = chatAdapter.getCount();
                        int nrOfNewMessages = countAfterUpdate - countBeforeUpdate;
                        view.addMessagesToNumberOfNewMessages(nrOfNewMessages);
                        temporaryRefresh();
                        smartScrollToBottom();
                        C.L("onMessagesReady!");
                    }
                });
                return null;
            }
        });
    }

    private void smartScrollToBottom() {
        if (view.getNumberOfNewMessages() == 1 && view.isLastPosVisible()) {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    removeLocalImageMessage();
                    view.updateList(chatAdapter);
                    view.scrollToBottom(chatAdapter);
                }
            });
        } else if ((!view.isLastPosVisible() && view.getNumberOfNewMessages() > 0) || view.getNumberOfNewMessages() > 1) {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    removeLocalImageMessage();
                    view.showNewMessagesButton();
                    view.updateList(chatAdapter);
                }
            });
        }
    }

    @Override
    public void onMessageSendClicked(final String message) {
        view.closeEmojiView();
        final String channelName = ConnectionManager.getInstance().getUser().getChannelName();
        final String roomId = ConnectionManager.getInstance().getHostConnectionForPos(connectionListPosition).getHost().getRoomId();
        ConnectionManager.getInstance().getHostConnectionForPos(connectionListPosition).sendMessage(handler, null, roomId, message, messagesCallback, channelName);
    }

    @Override
    public void onBackPressed() {
        if (!view.closeEmojiView()) {
            super.onBackPressed();
        }
    }

    @Override
    public void onNavigateBack() {
        onBackPressed();
    }

    private void tryConnecting() {
        ConnectionManager.getInstance().connectTo(connectionListPosition, new ConnectionManager.IConnectListener() {
            @Override
            public void onNoUsername(int pos) {

            }

            @Override
            public void onConnected(int pos) {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        getMessages();
                    }
                });
            }

            @Override
            public void onError(int pos) {
                view.showConnectionError();
            }
        });
    }

    @Override
    public void onTryAgain() {
        tryConnecting();
    }

    @Override
    public void onMessageClicked(final int messagePosition) {
        ConnectionManager.getInstance().connectTo(connectionListPosition, new ConnectionManager.IConnectListener() {
            @Override
            public void onNoUsername(int pos) {

            }

            @Override
            public void onConnected(int pos) {
                final String channelName = ConnectionManager.getInstance().getUser().getChannelName();
                Task.callInBackground(new Callable<Object>() {
                    @Override
                    public Object call() throws Exception {
                        ConnectionManager.getInstance().getHostConnectionForPos(connectionListPosition).resendMessage(handler, messagePosition, messagesCallback, filesCallback, channelName);
                        view.hideConnectionError();
                        return null;
                    }
                });
            }

            @Override
            public void onError(int pos) {
                view.showConnectionError();
            }
        });
    }

    @Override
    public void onDownloadOlderMessages() {
        if (!downloadingOlder) {
            downloadingOlder = true;
            Task.callInBackground(new Callable<Object>() {
                @Override
                public Object call() throws Exception {
                    ConnectionManager.getInstance().getHostConnectionForPos(connectionListPosition).loadOlderMessages(new HostConnection.IGetMessagesCallback() {
                        @Override
                        public void onErrorDuringConnection() {
                            C.L("ChatController->onDownloadOlderMessages->onErrorDuringConnection!!");
                            view.showConnectionError();
                            downloadingOlder = false;
                        }

                        @Override
                        public void onMessagesReady() {
                            view.updateList(chatAdapter);
                            C.L("onMessagesReady!");
                            downloadingOlder = false;
                        }
                    });
                    return null;
                }
            });
        }
    }

    @Override
    public void onAddClicked() {
        view.showAddOptions();
    }

    @Override
    public void onTakePhotoClicked() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            shareType = ShareType.CAMERA_TYPE;
            askForPermissionToWriteExternalFiles();
        } else {
            outputFileUri = ChatUtilities.takePhoto(this);
        }
    }

    @Override
    public void onSelectFileClicked() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            shareType = ShareType.FILE_TYPE;
            askForPermissionToReadExternalFiles();
        } else {
            ChatUtilities.selectFile(this);
        }
    }

    @Override
    public void onShareLocationClicked() {

    }

    @Override
    public void onSelectPhotoFromGalleryClicked() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            shareType = ShareType.IMAGE_TYPE;
            askForPermissionToReadExternalFiles();
        } else {
            ChatUtilities.selectImageFromGallery(this);
        }
    }

    private void askForPermissionToReadExternalFiles() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, C.ACTION_PERMISSION_REQUEST_READ_EXTERNAL_STORAGE);
        }
    }

    private void askForPermissionToWriteExternalFiles() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, C.ACTION_PERMISSION_REQUEST_WRITE_EXTERNAL_STORAGE);
        }
    }

    @SuppressLint("NewApi")
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case C.ACTION_PERMISSION_REQUEST_READ_EXTERNAL_STORAGE: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (shareType == ShareType.IMAGE_TYPE) {
                        ChatUtilities.selectImageFromGallery(this);
                    } else if (shareType == ShareType.FILE_TYPE) {
                        ChatUtilities.selectFile(this);
                    }
                } else {
                    if (shouldShowRequestPermissionRationale(Manifest.permission.READ_EXTERNAL_STORAGE)) {
                        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
                        builder.setTitle(null);
                        builder.setMessage(R.string.please_give_us_access_to_your_files);
                        builder.setPositiveButton(android.R.string.ok, null);
                        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            public void onDismiss(DialogInterface dialog) {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                    askForPermissionToReadExternalFiles();
                                }
                            }
                        });
                        builder.show();
                    } else {
                        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
                        builder.setTitle(null);
                        builder.setMessage(R.string.no_access_to_files_info);
                        builder.setPositiveButton(android.R.string.ok, null);
                        builder.show();
                    }
                }
            }
            case C.ACTION_PERMISSION_REQUEST_WRITE_EXTERNAL_STORAGE: {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    if (shareType == ShareType.CAMERA_TYPE) {
                        outputFileUri = ChatUtilities.takePhoto(this);
                    }
                } else {
                    if (shouldShowRequestPermissionRationale(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
                        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
                        builder.setTitle(null);
                        builder.setMessage(R.string.please_give_us_access_to_write_your_files);
                        builder.setPositiveButton(android.R.string.ok, null);
                        builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            public void onDismiss(DialogInterface dialog) {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                    askForPermissionToReadExternalFiles();
                                }
                            }
                        });
                        builder.show();
                    } else {
                        final android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
                        builder.setTitle(null);
                        builder.setMessage(R.string.no_access_to_write_files_info);
                        builder.setPositiveButton(android.R.string.ok, null);
                        builder.show();
                    }
                }
            }
        }
    }

    @Override
    public void onImageLoaded() {
        if (view.getNumberOfNewMessages() == 1 && view.isLastPosVisible()) {
            view.scrollToBottom(chatAdapter);
        }
    }
}
