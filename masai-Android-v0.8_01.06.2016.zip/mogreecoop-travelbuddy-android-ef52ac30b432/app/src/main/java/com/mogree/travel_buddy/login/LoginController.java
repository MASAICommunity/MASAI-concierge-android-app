package com.mogree.travel_buddy.login;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.communication.ConnectionManager;
import com.mogree.travel_buddy.core.model.User;
import com.mogree.travel_buddy.password_reset.PasswordResetController;
import com.mogree.travel_buddy.register.RegisterController;

public class LoginController extends AppCompatActivity implements LoginView.LoginViewListener {
    LoginView view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        view = new LoginView(findViewById(android.R.id.content), this, this);
    }

    @Override
    public void onContinueLogin(String email, String username, String password) {
        User user = new User();
        user.setEmail(email);
        user.setUsername(username);
        user.setPassword(password);
        ConnectionManager.getInstance().setUser(user);
        finish();
    }

    @Override
    public void onRegisterClicked() {
        finish();
        startActivity(new Intent(this, RegisterController.class));
    }

    @Override
    public void onPasswordResetClicked() {
        startActivity(new Intent(this, PasswordResetController.class));
    }
}