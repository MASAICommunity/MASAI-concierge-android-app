package com.mogree.travel_buddy.profile;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.communication.ConnectionManager;
import com.mogree.travel_buddy.core.communication.CustomRequests;
import com.mogree.travel_buddy.core.model.User;

public class ProfileController extends AppCompatActivity implements ProfileView.ProfileViewListener {
    ProfileView view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_view);
        view = new ProfileView(findViewById(android.R.id.content), this, this);
        User user = ConnectionManager.getInstance().getUser();
        String userName = user.getUsername();
        String email = user.getEmail();
        view.setUser(userName, email);
    }

    @Override
    public void onBackArrowPressed() {
        onBackPressed();
    }

    @Override
    public void onUpdate(String name, String password) {
        view.showProgress();
        final String hostUrl = ConnectionManager.getInstance().getHostConnectionForPos(0).getHost().getHostRocketChatApiUrl();
        final String token = ConnectionManager.getInstance().getHostConnectionForPos(0).getHost().getToken();
        final String userId = ConnectionManager.getInstance().getUser().getId();
        CustomRequests.updateMyAccount(hostUrl, token, userId, name, password, new CustomRequests.SimpleHttpResponseListener() {
            @Override
            public void onSuccess() {
                view.hideProgress();
            }

            @Override
            public void onFail() {
                view.hideProgress();
            }
        });
    }
}