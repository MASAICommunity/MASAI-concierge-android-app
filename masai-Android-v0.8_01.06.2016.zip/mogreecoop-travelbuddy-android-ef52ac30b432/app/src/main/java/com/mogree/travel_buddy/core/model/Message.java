package com.mogree.travel_buddy.core.model;

import com.google.gson.Gson;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

public class Message extends RealmObject {
    @PrimaryKey
    private String _id;
    private String t;
    private String rid;
    private int syncstate = SyncState.NOT_SYNCED;
    private long ts;
    private String msg;
    private User u;
    private boolean groupable;
    private String attachments;
    private int positionOnTheList;

    public Message() {
    }

    public boolean hasAttachments() {
        return getAttachments() != null && getAttachments().length > 0;
    }

    public boolean isContentEmpty() {
        return msg != null && msg.isEmpty();
    }

    public String getId() {
        return _id;
    }

    public void setId(String _id) {
        this._id = _id;
    }

    public String getType() {
        return t;
    }

    public void setType(String t) {
        this.t = t;
    }

    public String getRoomId() {
        return rid;
    }

    public void setRoomId(String rid) {
        this.rid = rid;
    }

    public int getSyncstate() {
        return syncstate;
    }

    public void setSyncstate(int syncstate) {
        this.syncstate = syncstate;
    }

    public long getTimeStamp() {
        return ts;
    }

    public void setTimeStamp(long ts) {
        this.ts = ts;
    }

    public String getMessage() {
        return msg;
    }

    public void setMessage(String msg) {
        this.msg = msg;
    }

    public User getUser() {
        return u;
    }

    public void setUser(User u) {
        this.u = u;
    }

    public boolean isGroupable() {
        return groupable;
    }

    public void setGroupable(boolean groupable) {
        this.groupable = groupable;
    }

    public boolean hasSameSenderAs(Message message) {
        return u.getUsername() != null && message.getUser().getUsername() != null && u.getUsername().equals(message.getUser().getUsername())
                || u.getEmail() != null && message.getUser().getEmail() != null && u.getEmail().equals(message.getUser().getEmail());
    }

    public int getPositionOnTheList() {
        return positionOnTheList;
    }

    public void setPositionOnTheList(int positionOnTheList) {
        this.positionOnTheList = positionOnTheList;
    }

    public MessageAttachment[] getAttachments() {
        MessageAttachment messageAttachments[] = null;
        if (attachments != null && !attachments.isEmpty()) {
            messageAttachments = new Gson().fromJson(attachments, MessageAttachment[].class);
        }
        return messageAttachments;
    }
}
