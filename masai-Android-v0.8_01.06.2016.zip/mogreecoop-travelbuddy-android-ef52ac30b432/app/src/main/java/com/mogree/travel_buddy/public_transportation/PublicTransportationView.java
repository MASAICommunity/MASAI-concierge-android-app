package com.mogree.travel_buddy.public_transportation;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.helper.TimeHelper;
import com.mogree.travel_buddy.core.model.Reservations;

/**
 * Created by Semko on 2016-12-05.
 */

public class PublicTransportationView {
    private View rootView;
    private PublicTransportationViewListener listener;
    private Context context;
    private Handler handler;
    private TextView tvTitle;
    private TextView tvTrainNumber;
    private TextView tvDepartureStationName;
    private TextView tvArrivalStationName;
    private TextView tvDepartureDate;
    private TextView tvDepartureTime;
    private TextView tvArrivalDate;
    private TextView tvArrivalTime;
    private TextView tvArrivalGate;
    private TextView tvDepartureGate;
    private TextView tvPassenger;
    private TextView tvTravelDuration;
    private TextView tvConfirmationNumber;
    private TextView tvSeat;
    private TextView tvClassType;
    private TextView tvLink;
    private ImageView ivBack;
    private ProgressDialog progressDialog;

    PublicTransportationView(View rootView, Context context, PublicTransportationViewListener listener) {
        this.rootView = rootView;
        this.context = context;
        this.listener = listener;
        handler = new Handler(Looper.getMainLooper());
        initViews();
    }

    private void initViews() {
        progressDialog = new ProgressDialog(context, ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage(rootView.getContext().getString(R.string.loading_data));
        progressDialog.setCanceledOnTouchOutside(false);
        tvTitle = (TextView) rootView.findViewById(R.id.activity_public_transportation_ala_action_bar_title);
        tvTrainNumber = (TextView) rootView.findViewById(R.id.activity_public_transportation_train_number);
        tvDepartureStationName = (TextView) rootView.findViewById(R.id.activity_public_transportation_from);
        tvArrivalStationName = (TextView) rootView.findViewById(R.id.activity_public_transportation_to);
        tvDepartureDate = (TextView) rootView.findViewById(R.id.activity_public_transportation_date);
        tvDepartureTime = (TextView) rootView.findViewById(R.id.activity_public_transportation_time);
        tvArrivalDate = (TextView) rootView.findViewById(R.id.activity_public_transportation_arrival_date);
        tvArrivalTime = (TextView) rootView.findViewById(R.id.activity_public_transportation_arrival_time);
        tvArrivalGate = (TextView) rootView.findViewById(R.id.activity_public_transportation_arrival_gate);
        tvDepartureGate = (TextView) rootView.findViewById(R.id.activity_public_transportation_departure_gate);
        tvPassenger = (TextView) rootView.findViewById(R.id.activity_public_transportation_passenger_name);
        tvTravelDuration = (TextView) rootView.findViewById(R.id.activity_public_transportation_duration);
        tvConfirmationNumber = (TextView) rootView.findViewById(R.id.activity_public_transportation_confirmation_number);
        tvSeat = (TextView) rootView.findViewById(R.id.activity_public_transportation_passenger_seat);
        tvClassType = (TextView) rootView.findViewById(R.id.activity_public_transportation_passenger_class_type);
        tvLink = (TextView) rootView.findViewById(R.id.activity_public_transportation_link);
        ivBack = (ImageView) rootView.findViewById(R.id.activity_public_transportation_ala_action_bar_back);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onNavigateBack();
            }
        });
    }

    public void setInfo(final Reservations.PublicTransportation reservation) {
        String departureTime = TimeHelper.getDateHM(TimeHelper.getCalendarFromStringYMDHMS(reservation.getDeparture().getUtcDateTime()));
        String arrivalTime = TimeHelper.getDateHM(TimeHelper.getCalendarFromStringYMDHMS(reservation.getArrival().getUtcDateTime()));
        String departureDate = context.getString(R.string.departs).concat(" ").concat(TimeHelper.getDateDayNrMonth(context, TimeHelper.getCalendarFromStringYMDHMS(reservation.getDeparture().getUtcDateTime())));
        String arrivalDate = context.getString(R.string.arrives).concat(" ").concat(TimeHelper.getDateDayNrMonth(context, TimeHelper.getCalendarFromStringYMDHMS(reservation.getArrival().getUtcDateTime())));
        long flightDuration = reservation.getDuration();
        String departureGate = reservation.getDeparture().getGate();
        String arrivalGate = reservation.getArrival().getGate();
        tvTrainNumber.setText(reservation.getTrainNumber());
        tvDepartureStationName.setText(reservation.getDeparture().getStationName());
        tvArrivalStationName.setText(reservation.getArrival().getStationName());
        tvDepartureDate.setText(departureDate);
        tvDepartureTime.setText(departureTime);
        tvArrivalDate.setText(arrivalDate);
        tvArrivalTime.setText(arrivalTime);
        String name = "";
        if (reservation.getTraveler() != null && reservation.getTraveler().getFirstName() != null && reservation.getTraveler().getLastName() != null) {
            name = reservation.getTraveler().getFirstName().concat(" ").concat(reservation.getTraveler().getLastName());
        }
        tvPassenger.setText(name);
        if (departureGate != null) {
            tvDepartureGate.setText(departureGate);
        }
        if (arrivalGate != null) {
            tvArrivalGate.setText(arrivalGate);
        }
        tvConfirmationNumber.setText(reservation.getBookingDetails().getConfirmationNumber());
        tvSeat.setText(reservation.getSeat());
        tvClassType.setText(reservation.getClassType());
        if (reservation.getBookingDetails() != null && reservation.getBookingDetails().getUrl() != null) {
            tvLink.setText(reservation.getBookingDetails().getUrl());
        }
        if (flightDuration == 0) {
            flightDuration = TimeHelper.getTravelDurationFromDepartureArrivalTimes(reservation.getDeparture().getUtcDateTime(), reservation.getArrival().getUtcDateTime());
        }
        tvTravelDuration.setText(TimeHelper.getDurationFromMinutes(context, (int) flightDuration));
    }

    public void showProgress() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                progressDialog.show();
            }
        });
    }

    public void hideProgress() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (progressDialog != null && progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
            }
        });
    }

    public void setTitle(final String title) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                tvTitle.setText(title);
            }
        });
    }

    public interface PublicTransportationViewListener {
        void onNavigateBack();
    }
}
