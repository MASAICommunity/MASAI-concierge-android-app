package com.mogree.travel_buddy.register;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.communication.ConnectionManager;
import com.mogree.travel_buddy.core.communication.HostConnection;
import com.mogree.travel_buddy.core.model.User;

public class RegisterController extends AppCompatActivity implements RegisterView.LoginViewListener {
    RegisterView view;
    Handler handler = new Handler(Looper.getMainLooper());
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = this;
        setContentView(R.layout.activity_register);
        view = new RegisterView(findViewById(android.R.id.content), this, this);
    }

    @Override
    public void onContinueRegister(final String email, final String name, final String password) {
        view.showProgress();
        HostConnection.registerUser(name, email, password, new HostConnection.IRegisterCallback() {
            @Override
            public void onRegistered() {
                view.hideProgress();
                User user = new User();
                user.setEmail(email);
                user.setFullName(name);
                user.setPassword(password);
                ConnectionManager.getInstance().setUser(user);
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        onBackPressed();
                    }
                });
            }

            @Override
            public void onErrorDuringConnection() {
                view.hideProgress();
                view.showRegisterError();
            }
        });
    }

    @Override
    public void onBackClicked() {
        onBackPressed();
    }
}