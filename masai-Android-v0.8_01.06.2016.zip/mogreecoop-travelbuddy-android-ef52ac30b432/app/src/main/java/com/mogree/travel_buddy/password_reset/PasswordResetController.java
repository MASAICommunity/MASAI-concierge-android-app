package com.mogree.travel_buddy.password_reset;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.communication.HostConnection;

public class PasswordResetController extends AppCompatActivity implements PasswordResetView.PasswordResetViewListener {
    PasswordResetView view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_reset);
        view = new PasswordResetView(findViewById(android.R.id.content), this, this);
    }

    @Override
    public void onBackArrowPressed() {
        onBackPressed();
    }

    @Override
    public void onEmailProvided(String email) {
        view.showProgress();
        HostConnection.resetPassword(email, new HostConnection.IResetPasswordCallback() {
            @Override
            public void onPasswordReset() {
                view.hideProgress();
                view.showEmailSentInfo();
                finish();
            }

            @Override
            public void onErrorDuringConnection() {
                view.hideProgress();
                view.showEmailErrorInfo();
            }
        });
    }
}