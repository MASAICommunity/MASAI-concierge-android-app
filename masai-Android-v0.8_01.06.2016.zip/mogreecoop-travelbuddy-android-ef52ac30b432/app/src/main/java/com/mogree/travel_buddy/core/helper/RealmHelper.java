package com.mogree.travel_buddy.core.helper;

import android.content.Context;

import com.mogree.travel_buddy.core.model.Host;
import com.mogree.travel_buddy.core.model.Message;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

import io.realm.Realm;
import io.realm.RealmChangeListener;
import io.realm.RealmConfiguration;
import io.realm.RealmResults;

/**
 * Created by Semko on 2016-12-06.
 */

public class RealmHelper {
    private static RealmHelper instance;

    public static RealmHelper getInstance() {
        if (instance == null) {
            instance = new RealmHelper();
        }
        return instance;
    }

    public void init(Context context) {
        Realm.init(context);
        RealmConfiguration config = new RealmConfiguration.Builder().deleteRealmIfMigrationNeeded().build();
        Realm.setDefaultConfiguration(config);
    }

    private long getNextKey(Realm realm, Class c) {
        Number mid = realm.where(c).max("id");
        if (mid != null) {
            return mid.longValue() + 1;
        }
        return 0;
    }

    public void executeCustomTransaction(Realm.Transaction transaction) {
        Realm realm = Realm.getDefaultInstance();
        realm.executeTransaction(transaction);
    }

    public void removeHost(final long id) {
        Realm realm = Realm.getDefaultInstance();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                Host host = realm.where(Host.class).equalTo("id", id).findFirst();
                if (host != null) {
                    host.deleteFromRealm();
                }
            }
        });
    }

    public Host addHost(final Host host) {
        Realm realm = Realm.getDefaultInstance();
        realm.beginTransaction();
        Host realmHost = realm.createObject(Host.class, getNextKey(realm, Host.class));
        realmHost.setHumanName(host.getHumanName());
        realmHost.setHostUrl(host.getHostUrl());
        realmHost.setHostRocketChatApiUrl(host.getHostRocketChatApiUrl());
        realm.commitTransaction();
        return realmHost;
    }

    public void updateHost(final Host host) {
        Realm realm = Realm.getDefaultInstance();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                realm.copyToRealmOrUpdate(host);
            }
        });
    }

    public Host[] getHostConnectionListListener(RealmChangeListener<RealmResults<Host>> listener) {
        Realm realm = Realm.getDefaultInstance();
        final RealmResults<Host> conversationList = realm.where(Host.class).findAll();
        conversationList.addChangeListener(listener);
        Host[] hosts = conversationList.toArray(new Host[]{});
        return hosts;
    }

    public List<Message> getMessages(int pos) {
        C.L("getMessages for POS=" + Integer.toString(pos));
        Realm realm = Realm.getDefaultInstance();
        final RealmResults<Message> messages = realm.where(Message.class).equalTo(C.JSON_FIELD_POS_ON_THE_LIST, pos).findAllSorted(C.JSON_FIELD_TIMESTAMP);
        return messages.subList(0, messages.size());
    }

    public Message getFirstMessage(int pos) {
        C.L("getFirstMessage for POS=" + Integer.toString(pos));
        Realm realm = Realm.getDefaultInstance();
        final RealmResults<Message> messages = realm.where(Message.class).equalTo(C.JSON_FIELD_POS_ON_THE_LIST, pos).findAllSorted(C.JSON_FIELD_TIMESTAMP);
        if (messages.size() == 0) {
            return null;
        } else {
            return messages.get(0);
        }
    }

    public Message getLatestMessage(int pos) {
        C.L("getLatestMessage for POS=" + Integer.toString(pos));
        Realm realm = Realm.getDefaultInstance();
        final RealmResults<Message> messages = realm.where(Message.class).equalTo(C.JSON_FIELD_POS_ON_THE_LIST, pos).findAllSorted(C.JSON_FIELD_TIMESTAMP);
        if (messages.size() == 0) {
            return null;
        } else {
            return messages.get(messages.size() - 1);
        }
    }

    public void removeMessageWithId(final int pos, final String messageID) {
        C.L("updateMessageState for POS=" + Integer.toString(pos));
        Realm realm = Realm.getDefaultInstance();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                final RealmResults<Message> conversationList = realm.where(Message.class).equalTo(C.JSON_FIELD_POS_ON_THE_LIST, pos).equalTo(C.JSON_FIELD_ID, messageID).findAll();
                for (Message message : conversationList) {
                    message.deleteFromRealm();
                }
            }
        });
    }

    public void addMessageFromJson(final JSONObject json) {
        Realm realm = Realm.getDefaultInstance();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                realm.createOrUpdateObjectFromJson(Message.class, json);
            }
        });
    }

    public void updateMessageState(final int pos, final String messageID, final int syncState) {
        C.L("updateMessageState for POS=" + Integer.toString(pos));
        Realm realm = Realm.getDefaultInstance();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                final RealmResults<Message> conversationList = realm.where(Message.class).equalTo(C.JSON_FIELD_POS_ON_THE_LIST, pos).equalTo(C.JSON_FIELD_ID, messageID).findAll();
                for (Message message : conversationList) {
                    message.setSyncstate(syncState);
                    realm.copyToRealmOrUpdate(message);
                }
            }
        });
    }

    public void addMessagesFromJson(final JSONArray jsonArray, int pos) {
        C.L("addMessagesFromJson for POS=" + Integer.toString(pos));
        Realm realm = Realm.getDefaultInstance();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                realm.createOrUpdateAllFromJson(Message.class, jsonArray);
            }
        });
    }
}
