package com.mogree.travel_buddy.login;

import android.content.Context;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.mogree.travel_buddy.R;

public class LoginView {
    private View rootView;
    private LoginViewListener listener;
    private Context context;
    private EditText etUsername;
    private EditText etPassword;
    private TextView tvResetPassword;
    private TextView tvRegister;
    private Button btnContinue;

    LoginView(View rootView, Context context, LoginViewListener listener) {
        this.rootView = rootView;
        this.context = context;
        this.listener = listener;
        initViews();
    }

    private void initViews() {
        etUsername = (EditText) rootView.findViewById(R.id.et_user_name);
        etPassword = (EditText) rootView.findViewById(R.id.et_user_pass);
        tvResetPassword = (TextView) rootView.findViewById(R.id.tv_reset_pass);
        tvRegister = (TextView) rootView.findViewById(R.id.tv_register);
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onRegisterClicked();
            }
        });
        tvResetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onPasswordResetClicked();
            }
        });

        btnContinue = (Button) rootView.findViewById(R.id.btn_user_login);
        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String usernameOrEmail = etUsername.getText().toString();
                if (Patterns.EMAIL_ADDRESS.matcher(usernameOrEmail).matches()) {
                    listener.onContinueLogin(usernameOrEmail, "", etPassword.getText().toString());
                } else {
                    listener.onContinueLogin("", usernameOrEmail, etPassword.getText().toString());
                }
            }
        });
    }

    interface LoginViewListener {

        void onContinueLogin(String email, String username, String password);

        void onRegisterClicked();

        void onPasswordResetClicked();
    }
}
