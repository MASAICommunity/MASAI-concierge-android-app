package com.mogree.travel_buddy.add_host;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.chat.ChatController;
import com.mogree.travel_buddy.core.communication.ConnectionManager;
import com.mogree.travel_buddy.core.communication.HostConnection;
import com.mogree.travel_buddy.core.helper.C;
import com.mogree.travel_buddy.core.model.Host;
import com.mogree.travel_buddy.core.model.User;
import com.mogree.travel_buddy.set_username.SetUsernameController;

import java.util.List;
import java.util.concurrent.Callable;

import bolts.Task;

public class AddHostController extends AppCompatActivity implements AddHostView.AddHostViewListener {
    private AddHostView view;
    private AddHostListAdapter addHostListAdapter;
    private Context context;
    private Handler handler;
    private List<Host> hostList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.context = this;
        handler = new Handler(Looper.getMainLooper());
        setContentView(R.layout.activity_server_list);
        view = new AddHostView(findViewById(android.R.id.content), this, this);
        initViews();
        view.setTitle(getString(R.string.select_host));
        hostList = ConnectionManager.getInstance().getHostList();
        if (hostList != null && hostList.size() > 0) {
            addHostListAdapter = new AddHostListAdapter(this, hostList);
            view.setAddHostListAdapter(addHostListAdapter);
        } else {
            finish();
        }
    }

    private void initViews() {

    }

    private void removeConnection(final int pos) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                ConnectionManager.getInstance().removeConnection(pos);
            }
        });
    }

    void setUsername(final int pos) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(context, SetUsernameController.class);
                intent.putExtra(C.EXTRA_HOST_CONNECTION_POSITION, pos);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    public void onHostClicked(final int position) {
        view.showProgress();
        int existsAtPos = ConnectionManager.getInstance().hasHost(position);
        if (existsAtPos > -1) {
            startChat(existsAtPos);
        } else {
            ConnectionManager.getInstance().addConnection(position, new ConnectionManager.IConnectListener() {
                @Override
                public void onNoUsername(final int pos) {
                    setUsername(pos);
                }

                @Override
                public void onConnected(final int pos) {
                    C.L("Connection sucsseded");
                    createChannel(pos);
                }

                @Override
                public void onError(final int pos) {
                    C.L("Connection failed");
                    view.hideProgress();
                    removeConnection(pos);
                    finish();
                    returnToLogin();
                }
            });
        }
    }

    private void createChannel(final int pos) {
        ConnectionManager.getInstance().getHostConnectionForPos(pos).createAChannelIfDoesNotExists(new HostConnection.IChannelCreatedCallback() {
            @Override
            public void onChannelCreated() {
                String roomId = ConnectionManager.getInstance().getHostConnectionForPos(pos).getHost().getRoomId();
                C.L("Channel created or found successfully with roomid = " + roomId);
                loadMessages(roomId, pos);
            }

            @Override
            public void onErrorDuringConnection() {
                C.L("Channel creation failed");
                removeConnection(pos);
                returnToLogin();
                view.hideProgress();
                finish();
            }
        });
    }

    private void returnToLogin() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                ConnectionManager.getInstance().setUser(new User());
                Toast.makeText(context, R.string.login_failed, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void loadMessages(final String roomId, final int pos) {
        Task.callInBackground(new Callable<Object>() {
            @Override
            public Object call() throws Exception {
                ConnectionManager.getInstance().getHostConnectionForPos(pos).loadMessagesFromWhileIWasAway(roomId, new HostConnection.IGetMessagesCallback() {
                    @Override
                    public void onMessagesReady() {
                        startChat(pos);
                        view.hideProgress();
                    }

                    @Override
                    public void onErrorDuringConnection() {
                        startChat(pos);
                        view.hideProgress();
                    }
                });
                return null;
            }
        });
    }

    @Override
    protected void onStop() {
        handler.removeCallbacksAndMessages(null);
        super.onStop();
    }

    private void startChat(int pos) {
        Intent intent = new Intent(context, ChatController.class);
        intent.putExtra(C.EXTRA_HOST_CONNECTION_POSITION, pos);
        finish();
        startActivity(intent);
    }

    @Override
    public void onNavigateBack() {
        onBackPressed();
    }
}
