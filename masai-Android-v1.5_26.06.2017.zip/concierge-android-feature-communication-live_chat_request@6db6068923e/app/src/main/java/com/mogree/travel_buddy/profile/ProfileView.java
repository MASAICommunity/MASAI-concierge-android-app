package com.mogree.travel_buddy.profile;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebView;

import com.mogree.travel_buddy.R;

public class ProfileView {
    private View rootView;
    private ProfileViewListener listener;
    private Context context;
    private WebView travelfolderWebView;
    private ProgressDialog progressDialog;
    private Handler handler;

    ProfileView(View rootView, Context context, ProfileViewListener listener) {
        this.rootView = rootView;
        this.context = context;
        this.listener = listener;
        handler = new Handler(Looper.getMainLooper());
        initViews();
    }

    private void initViews() {
        progressDialog = new ProgressDialog(context, ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage(rootView.getContext().getString(R.string.loading_data));
        progressDialog.setCanceledOnTouchOutside(false);
        travelfolderWebView = (WebView) rootView.findViewById(R.id.profile_web_view);
    }

    public void setTravelfolderWebViewData(String idToken) {
        String ua = "Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.4) Gecko/20100101 Firefox/4.0";
        CookieManager.getInstance().setCookie("https://travelfolder.masai.solutions/", "id_token=" + idToken);
        travelfolderWebView.getSettings().setUserAgentString(ua);
        travelfolderWebView.getSettings().setJavaScriptEnabled(true);
        travelfolderWebView.getSettings().setLoadWithOverviewMode(true);
        travelfolderWebView.getSettings().setUseWideViewPort(true);
        travelfolderWebView.getSettings().setDomStorageEnabled(true);

        travelfolderWebView.getSettings().setSupportZoom(true);
        travelfolderWebView.getSettings().setBuiltInZoomControls(true);
        travelfolderWebView.getSettings().setDisplayZoomControls(false);

        travelfolderWebView.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
        travelfolderWebView.setScrollbarFadingEnabled(false);
        travelfolderWebView.loadUrl("https://travelfolder.masai.solutions/#/profile");
    }

    public void showProgress() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                progressDialog.show();
            }
        });
    }

    public void hideProgress() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (progressDialog != null && progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
            }
        });
    }

    interface ProfileViewListener {
        void onBackArrowPressed();

        void onUpdate(String name, String password);
    }
}