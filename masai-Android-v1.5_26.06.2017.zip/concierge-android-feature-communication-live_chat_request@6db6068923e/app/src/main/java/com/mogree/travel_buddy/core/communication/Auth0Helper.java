package com.mogree.travel_buddy.core.communication;

import android.app.Activity;
import android.app.Dialog;
import android.support.annotation.NonNull;

import com.auth0.android.Auth0;
import com.auth0.android.authentication.AuthenticationAPIClient;
import com.auth0.android.authentication.AuthenticationException;
import com.auth0.android.authentication.request.SignUpRequest;
import com.auth0.android.callback.AuthenticationCallback;
import com.auth0.android.provider.AuthCallback;
import com.auth0.android.provider.WebAuthProvider;
import com.auth0.android.request.AuthenticationRequest;
import com.auth0.android.result.Credentials;
import com.auth0.android.result.UserProfile;
import com.mogree.travel_buddy.core.model.User;

/**
 * Created by Semko on 2017-04-05.
 */

public class Auth0Helper {
    private static final String CLIENT_ID = "kBLUvsCh4ssDFnE8oVXd2BJ357FcCj5p";
    private static final String DOMAIN = "masai.eu.auth0.com";
    private static final String CONNECTION_NAME = "Username-Password-Authentication";
    private AuthenticationAPIClient authentication;
    private static Auth0Helper instance;
    private Auth0 auth0;

    private Auth0Helper() {
        init();
    }

    public static Auth0Helper getInstance() {
        if (instance == null) {
            instance = new Auth0Helper();
        }
        return instance;
    }

    private void init() {
        auth0 = new Auth0(CLIENT_ID, DOMAIN);
        authentication = new AuthenticationAPIClient(auth0);
    }

    public static void clear() {
        instance = null;
    }

    public void singUp(final String email, final String password, final String username, final ISingUp listener) {
        SignUpRequest signUpRequest;
        signUpRequest = authentication.signUp(email, password, username, CONNECTION_NAME);
        signUpRequest.start(new AuthenticationCallback<Credentials>() {
            @Override
            public void onSuccess(Credentials payload) {
                getAuth0UserInfo(payload, new ILogIn() {
                    @Override
                    public void onLoggedIn() {
                        listener.onSingedUp();
                    }

                    @Override
                    public void onLoginError() {
                        listener.onSingUpError();
                    }

                    @Override
                    public void onBadCredentials() {
                        listener.onSingUpError();
                    }
                });
                listener.onSingedUp();
            }

            @Override
            public void onFailure(AuthenticationException error) {
                if (error.getCode() != null && error.getCode().contains("user_exists")) {
                    listener.onBadUser();
                } else {
                    listener.onSingUpError();
                }
            }
        });
    }

    private String getUsernameFromEmail(String email) {
        String emailSplit[] = email.split("[@]");
        if (emailSplit.length > 0) {
            return emailSplit[0];
        }
        return email;
    }

    public void logIn(final String email, final String password, final String username, final ILogIn listener) {
        AuthenticationRequest loginRequest;
        if (username == null || username.isEmpty()) {
            loginRequest = authentication.loginWithEmail(email, password, CONNECTION_NAME);
        } else {
            loginRequest = authentication.login(username, password, CONNECTION_NAME);
        }
        loginRequest.start(new AuthenticationCallback<Credentials>() {
            @Override
            public void onSuccess(Credentials payload) {
                getAuth0UserInfo(payload, listener);
            }

            @Override
            public void onFailure(AuthenticationException error) {
                ConnectionManager.getInstance().setUser(null);
                if (error.getCode() != null && error.getCode().contains("invalid_user_password")) {
                    listener.onBadCredentials();
                } else {
                    listener.onLoginError();
                }
            }
        });
    }

    public void logInWithFacebook(Activity activity, final ILogIn listener) {
        handleSocialLogin(WebAuthProvider.init(auth0).withConnection("facebook")
                .withConnectionScope("public_profile,email,user_friends")
                .withScheme("concergie")
                .withScope("openid"), listener, activity);
    }

    public void logInWithGoogle(Activity activity, final ILogIn listener) {
        handleSocialLogin(WebAuthProvider.init(auth0).withConnection("google-oauth2").withScheme("concergie")
                .withScope("openid"), listener, activity);
    }

    public void logInWithTwitter(Activity activity, final ILogIn listener) {
        handleSocialLogin(WebAuthProvider.init(auth0).withConnection("twitter").withScheme("concergie")
                .withScope("openid"), listener, activity);
    }

    public void logInWithLinkedIn(Activity activity, final ILogIn listener) {
        handleSocialLogin(WebAuthProvider.init(auth0).withConnection("linkedin").withScheme("concergie")
                .withScope("openid"), listener, activity);
    }

    private void getAuth0UserInfo(final Credentials credentials, final ILogIn listener) {
        authentication.userInfo(credentials.getAccessToken()).start(new AuthenticationCallback<UserProfile>() {
            @Override
            public void onSuccess(UserProfile payload) {
                if (payload != null && payload.getId() != null) {
                    handleLogin(credentials.getIdToken(), credentials.getAccessToken(), payload.getEmail(), payload.getNickname(), null, payload.getName(), payload.getId());
                    listener.onLoggedIn();
                } else {
                    listener.onLoginError();
                }
            }

            @Override
            public void onFailure(AuthenticationException error) {
                listener.onLoginError();
            }
        });
    }

    private void handleSocialLogin(WebAuthProvider.Builder builder, final ILogIn listener, Activity activity) {
        builder.start(activity, new AuthCallback() {
            @Override
            public void onFailure(@NonNull Dialog dialog) {
                listener.onLoginError();
            }

            @Override
            public void onFailure(AuthenticationException exception) {
                listener.onLoginError();
            }

            @Override
            public void onSuccess(final @NonNull Credentials credentials) {
                getAuth0UserInfo(credentials, listener);
            }
        });
    }

    private void handleLogin(String idToken, String accessToken, final String email, final String username, final String password, final String fullname, final String auth0Id) {
        User newUser = new User();
        newUser.setAuth0Id(auth0Id);
        newUser.setEmail(email);
        if (password != null && !password.isEmpty()) {
            newUser.setPassword(password);
        }
        if (username == null || username.isEmpty()) {
            newUser.setUsername(getUsernameFromEmail(email));
        } else {
            newUser.setUsername(username);
        }
        if (fullname != null && !fullname.isEmpty()) {
            newUser.setFullName(fullname);
        }
        newUser.setIdToken(idToken);
        newUser.setAccessToken(accessToken);
        ConnectionManager.getInstance().setUser(newUser);
    }

    public interface ILogIn {
        void onLoggedIn();

        void onLoginError();

        void onBadCredentials();

    }

    public interface ISingUp {

        void onBadUser();

        void onSingedUp();

        void onSingUpError();
    }
}
