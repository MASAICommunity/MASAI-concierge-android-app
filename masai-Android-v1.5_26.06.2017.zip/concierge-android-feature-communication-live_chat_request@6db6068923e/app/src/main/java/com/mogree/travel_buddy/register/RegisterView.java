package com.mogree.travel_buddy.register;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.helper.DialogHelper;

public class RegisterView {
    private View rootView;
    private LoginViewListener listener;
    private Context context;
    private EditText etName;
    private EditText etEmail;
    private EditText etPassword;
    private EditText etPassword2;
    private Button btnContinue;
    private ProgressDialog progressDialog;
    private Handler handler;

    RegisterView(View rootView, Context context, LoginViewListener listener) {
        this.rootView = rootView;
        this.context = context;
        this.listener = listener;
        handler = new Handler(Looper.getMainLooper());
        initViews();
    }

    private void showOkDialog(final int message) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                DialogHelper.dialogOk(context, message);
            }
        });
    }

    private void initViews() {
        progressDialog = new ProgressDialog(context, ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage(rootView.getContext().getString(R.string.loading_data));
        progressDialog.setCanceledOnTouchOutside(false);
        etName = (EditText) rootView.findViewById(R.id.et_register_name);
        etEmail = (EditText) rootView.findViewById(R.id.et_register_email);
        etPassword = (EditText) rootView.findViewById(R.id.et_register_pass);
        etPassword2 = (EditText) rootView.findViewById(R.id.et_register_pass2);
        btnContinue = (Button) rootView.findViewById(R.id.btn_submit_username);
        btnContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = etEmail.getText().toString();
                String name = etName.getText().toString();
                String password = etPassword.getText().toString();
                String password2 = etPassword2.getText().toString();
                if (name.isEmpty()) {
                    etName.setError(context.getString(R.string.enter_correct_name));
                    return;
                } else {
                    etName.setError(null);
                }
                if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                    etEmail.setError(context.getString(R.string.enter_correct_email));
                    return;
                } else {
                    etEmail.setError(null);
                }
                if (password.isEmpty()) {
                    etPassword.setError(context.getString(R.string.enter_password));
                    return;
                } else {
                    etPassword.setError(null);
                }
                if (password2.isEmpty()) {
                    etPassword2.setError(context.getString(R.string.enter_password));
                    return;
                } else {
                    etPassword2.setError(null);
                }
                if (!password.equals(password2)) {
                    etPassword.setError(context.getString(R.string.passwords_dont_match));
                    etPassword2.setError(context.getString(R.string.passwords_dont_match));
                    return;
                } else {
                    etPassword2.setError(null);
                    etPassword.setError(null);
                }
                listener.onContinueRegister(email, name, password);
            }
        });
    }

    void showEmailExistError() {
        showOkDialog(R.string.email_exist_error);
    }

    void showConnectivityError() {
        showOkDialog(R.string.connection_restore);
    }

    void showProgress() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                progressDialog.show();
            }
        });
    }

    public void hideProgress() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (progressDialog != null && progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
            }
        });
    }

    void showServerError() {
        showOkDialog(R.string.server_error);
    }

    void showUsernameTakenError() {
        showOkDialog(R.string.username_taken);
    }

    void showRegisterError() {
        showOkDialog(R.string.register_error);
    }

    interface LoginViewListener {

        void onContinueRegister(String email, String name, String password);

        void onBackClicked();
    }
}
