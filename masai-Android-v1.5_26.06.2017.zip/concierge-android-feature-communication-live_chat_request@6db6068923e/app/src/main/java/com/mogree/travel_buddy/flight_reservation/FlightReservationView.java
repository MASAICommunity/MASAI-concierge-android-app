package com.mogree.travel_buddy.flight_reservation;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.helper.TimeHelper;
import com.mogree.travel_buddy.core.model.Reservations;

/**
 * Created by Semko on 2016-12-05.
 */

public class FlightReservationView {
    private View rootView;
    private FlightReservationViewListener listener;
    private Context context;
    private Handler handler;
    private TextView tvTitle;
    private TextView tvAirhost;
    private TextView tvDepartureAirportCode;
    private TextView tvArrivalAirportCode;
    private TextView tvDepartureDate;
    private TextView tvDepartureTime;
    private TextView tvArrivalDate;
    private TextView tvArrivalTime;
    private TextView tvDepartureTerminal;
    private TextView tvDepartureGate;
    private TextView tvArrivalTerminal;
    private TextView tvArrivalGate;
    private TextView tvFlightDuration;
    private TextView tvConfirmationNumber;
    private TextView tvPassengerName;
    private TextView tvSeat;
    private ImageView ivBack;
    private ProgressDialog progressDialog;

    FlightReservationView(View rootView, Context context, FlightReservationViewListener listener) {
        this.rootView = rootView;
        this.context = context;
        this.listener = listener;
        handler = new Handler(Looper.getMainLooper());
        initViews();
    }

    private void initViews() {
        progressDialog = new ProgressDialog(context, ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage(rootView.getContext().getString(R.string.loading_data));
        progressDialog.setCanceledOnTouchOutside(false);
        tvTitle = (TextView) rootView.findViewById(R.id.activity_flight_reservation_ala_action_bar_title);
        tvAirhost = (TextView) rootView.findViewById(R.id.activity_flight_airhost);
        tvArrivalAirportCode = (TextView) rootView.findViewById(R.id.activity_flight_arrival_airport_code);
        tvDepartureAirportCode = (TextView) rootView.findViewById(R.id.activity_flight_departure_airport_code);
        tvDepartureDate = (TextView) rootView.findViewById(R.id.activity_flight_departure_date);
        tvDepartureTime = (TextView) rootView.findViewById(R.id.activity_flight_departure_time);
        tvDepartureTerminal = (TextView) rootView.findViewById(R.id.activity_flight_departure_terminal);
        tvDepartureGate = (TextView) rootView.findViewById(R.id.activity_flight_departure_gate);
        tvArrivalDate = (TextView) rootView.findViewById(R.id.activity_flight_arrival_date);
        tvArrivalTime = (TextView) rootView.findViewById(R.id.activity_flight_arrival_time);
        tvArrivalTerminal = (TextView) rootView.findViewById(R.id.activity_flight_arrival_terminal);
        tvArrivalGate = (TextView) rootView.findViewById(R.id.activity_flight_arrival_gate);
        tvFlightDuration = (TextView) rootView.findViewById(R.id.activity_flight_duration);
        tvConfirmationNumber = (TextView) rootView.findViewById(R.id.activity_confirmation_number);
        tvPassengerName = (TextView) rootView.findViewById(R.id.activity_flight_passenger_name);
        tvSeat = (TextView) rootView.findViewById(R.id.activity_flight_seat);
        ivBack = (ImageView) rootView.findViewById(R.id.activity_flight_reservation_ala_action_bar_back);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onNavigateBack();
            }
        });
    }

    public void setInfo(final Reservations.FlightReservation reservation) {
        String departureTime = TimeHelper.getDateHM(TimeHelper.getCalendarFromStringYMDHMS(reservation.getDeparture().getUtcDateTime()));
        String arrivalTime = TimeHelper.getDateHM(TimeHelper.getCalendarFromStringYMDHMS(reservation.getArrival().getUtcDateTime()));
        String departureDate = context.getString(R.string.departs).concat(" ").concat(TimeHelper.getDateDayNrMonth(context, TimeHelper.getCalendarFromStringYMDHMS(reservation.getDeparture().getUtcDateTime())));
        String arrivalDate = context.getString(R.string.arrives).concat(" ").concat(TimeHelper.getDateDayNrMonth(context, TimeHelper.getCalendarFromStringYMDHMS(reservation.getArrival().getUtcDateTime())));
        long flightDuration = reservation.getDuration();
        String departureGate = reservation.getDeparture().getGate();
        String arrivalGate = reservation.getArrival().getGate();
        String departureTerminal = reservation.getDeparture().getTerminal();
        String arrivalTerminal = reservation.getArrival().getTerminal();
        String airhost = "";
        if (reservation.getBookingDetails() != null && reservation.getBookingDetails().getName() != null) {
            airhost = reservation.getBookingDetails().getName().concat(" ").concat(Long.toString(reservation.getDetails().getNumber()));
        }
        tvAirhost.setText(airhost);
        tvArrivalAirportCode.setText(reservation.getArrival().getAirportCode());
        tvDepartureDate.setText(departureDate);
        tvDepartureTime.setText(departureTime);
        tvConfirmationNumber.setText(reservation.getBookingDetails().getConfirmationNumber());
        tvDepartureAirportCode.setText(reservation.getDeparture().getAirportCode());
        String passengerName = "";
        if (reservation.getTraveler() != null && reservation.getTraveler().getFirstName() != null) {
            passengerName = reservation.getTraveler().getFirstName().concat(" ").concat(reservation.getTraveler().getLastName());
        }
        tvPassengerName.setText(passengerName);
        tvSeat.setText("-");
        if (flightDuration == 0) {
            flightDuration = TimeHelper.getTravelDurationFromDepartureArrivalTimes(reservation.getDeparture().getUtcDateTime(), reservation.getArrival().getUtcDateTime());
        }
        tvFlightDuration.setText(TimeHelper.getDurationFromMinutes(context, (int) flightDuration));
        if (departureGate != null && !departureGate.isEmpty()) {
            tvDepartureGate.setText(departureGate);
        } else {
            tvDepartureGate.setText("-");
        }
        if (departureTerminal != null && !departureTerminal.isEmpty()) {
            tvDepartureTerminal.setText(departureTerminal);
        } else {
            tvDepartureTerminal.setText("-");
        }
        tvArrivalDate.setText(arrivalDate);
        tvArrivalTime.setText(arrivalTime);
        tvArrivalAirportCode.setText(reservation.getArrival().getAirportCode());
        if (arrivalGate != null && !arrivalGate.isEmpty()) {
            tvArrivalGate.setText(arrivalGate);
        } else {
            tvArrivalGate.setText("-");
        }
        if (arrivalTerminal != null && !arrivalTerminal.isEmpty()) {
            tvArrivalTerminal.setText(arrivalTerminal);
        } else {
            tvArrivalTerminal.setText("-");
        }
    }

    public void showProgress() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                progressDialog.show();
            }
        });
    }

    public void hideProgress() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (progressDialog != null && progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
            }
        });
    }

    public void setTitle(final String title) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                tvTitle.setText(title);
            }
        });
    }

    public interface FlightReservationViewListener {
        void onNavigateBack();
    }
}
