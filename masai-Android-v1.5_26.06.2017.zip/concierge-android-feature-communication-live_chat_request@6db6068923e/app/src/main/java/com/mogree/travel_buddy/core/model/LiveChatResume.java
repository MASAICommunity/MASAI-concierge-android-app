package com.mogree.travel_buddy.core.model;

/**
 * Created by Semko on 2017-04-10.
 */

public class LiveChatResume {
    private String resume;

    public String getResume() {
        return resume;
    }

    public void setResume(String resume) {
        this.resume = resume;
    }
}
