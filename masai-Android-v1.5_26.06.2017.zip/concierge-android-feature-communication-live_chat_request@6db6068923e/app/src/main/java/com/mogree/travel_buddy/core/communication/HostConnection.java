package com.mogree.travel_buddy.core.communication;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.google.gson.Gson;
import com.mogree.travel_buddy.chat.ChatUtilities;
import com.mogree.travel_buddy.core.helper.C;
import com.mogree.travel_buddy.core.helper.FileHelper;
import com.mogree.travel_buddy.core.helper.OkHttpHelper;
import com.mogree.travel_buddy.core.helper.PrefsHelper;
import com.mogree.travel_buddy.core.helper.RealmHelper;
import com.mogree.travel_buddy.core.helper.RegexHelper;
import com.mogree.travel_buddy.core.model.Host;
import com.mogree.travel_buddy.core.model.LiveChatMessage;
import com.mogree.travel_buddy.core.model.LiveChatRegisterGuest;
import com.mogree.travel_buddy.core.model.LiveChatResume;
import com.mogree.travel_buddy.core.model.LivechatUser;
import com.mogree.travel_buddy.core.model.Message;
import com.mogree.travel_buddy.core.model.MessageAttachment;
import com.mogree.travel_buddy.core.model.MeteorFile;
import com.mogree.travel_buddy.core.model.MeteorFileSendMessage;
import com.mogree.travel_buddy.core.model.MeteorMessage;
import com.mogree.travel_buddy.core.model.MeteorRoomId;
import com.mogree.travel_buddy.core.model.SyncState;
import com.mogree.travel_buddy.core.model.Timestamp;
import com.mogree.travel_buddy.core.model.User;

import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.Callable;

import bolts.Task;
import im.delight.android.ddp.Meteor;
import im.delight.android.ddp.MeteorCallback;
import im.delight.android.ddp.ResultListener;
import im.delight.android.ddp.SubscribeListener;
import io.realm.Realm;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okio.BufferedSink;
import okio.Okio;
import okio.Source;

/**
 * Created by Semko on 2017-02-17.
 */

public class HostConnection implements MeteorCallback {
    private Meteor meteor;
    private User user;
    private Host host;
    private IHostConnectionCallback hostConnectionListener;
    private int connectionPositionOnList;
    private String subscriptionId;
    private Handler handler = new Handler(Looper.getMainLooper());
    private String liveChatToken = "";
    private String liveChatRoomId = "";
    private String liveChatUserLoginToken = "";
    private String liveChatUserId = "";

    public HostConnection(Host host, User user) {
        this.user = user;
        this.host = host;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public User getUser() {
        return user;
    }

    public void connectIfDisconnectedAndSetHostListener(Context context, HostConnection.IHostConnectionCallback hostConnectionListener) {
        if (hostConnectionListener != null) {
            this.hostConnectionListener = hostConnectionListener;
        }
        if (meteor == null || !meteor.isConnected()) {
            meteor = new Meteor(context, host.getHostUrl());
            meteor.addCallback(this);
            meteor.connect();
        } else if (meteor.isConnected()) {
            if (hostConnectionListener != null) {
                hostConnectionListener.onConnectedAndLoggedIn();
            }
        }
    }

    int getConnectionPositionOnList() {
        return connectionPositionOnList;
    }

    void setConnectionPositionOnList(int connectionPositionOnList) {
        this.connectionPositionOnList = connectionPositionOnList;
    }

    private void updateRoomId(final String roomId, final IChannelCreatedCallback listener) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                RealmHelper.getInstance().executeCustomTransaction(new Realm.Transaction() {
                    @Override
                    public void execute(Realm realm) {
                        if (host.isValid()) {
                            host.setRoomId(roomId);
                            realm.copyToRealmOrUpdate(host);
                            listener.onChannelCreated(roomId);
                        }
                    }
                });
            }
        });
    }

    public void loadMessagesFromWhileIWasAway(final String roomId, final IGetMessagesCallback listener) {
        C.L("loadMessagesFromWhileIWasAway1");
        Message message = RealmHelper.getInstance().getFirstMessage(connectionPositionOnList);
        C.L("loadMessagesFromWhileIWasAway2");
        if (message == null) {
            C.L("loadMessagesFromWhileIWasAway2.5");
            long ts = System.currentTimeMillis();
            C.L("loadMessagesFromWhileIWasAway3 for roomid " + roomId);
            loadHistory(roomId, 0, 50, ts, listener);
        } else {
            C.L("loadMessagesFromWhileIWasAway4");
            loadHistory(roomId, 0, 50, 0, listener);
        }
    }

    private void loadHistory(final String roomId, final long timestamp, final int count, final long lastSeen, final IGetMessagesCallback listener) {
        C.L("SAFE loadHistory");
        Timestamp timestampTS = new Timestamp();
        timestampTS.setTimestamp(timestamp);
        Timestamp lastSeenTS = new Timestamp();
        lastSeenTS.setTimestamp(lastSeen);
        Object oldestMessageTimestamp = timestamp > 0 ? timestampTS : null;
        Object lastMessageTimestamp = lastSeen > 0 ? timestampTS : null;
        Object args[] = new Object[]{roomId, oldestMessageTimestamp, count, lastMessageTimestamp};
        meteor.call(C.RPC_LOAD_HISTORY, args, new ResultListener() {
            @Override
            public void onSuccess(String result) {
                try {
                    C.L("messages downloaded = " + result);
                    String modedJsonString = RegexHelper.simplifyDate(result);
                    modedJsonString = RegexHelper.simplifyLocation(modedJsonString);
                    C.L("messages downloaded and moded = " + modedJsonString);
                    JSONObject messagesJsonObject = new JSONObject(modedJsonString);
                    if (messagesJsonObject.has(C.JSON_FIELD_MESSAGES)) {
                        final JSONArray messageJsonArray = messagesJsonObject.getJSONArray(C.JSON_FIELD_MESSAGES);
                        for (int co0 = 0; co0 < messageJsonArray.length(); ++co0) {
                            messageJsonArray.getJSONObject(co0).put(C.JSON_FIELD_POS_ON_THE_LIST, connectionPositionOnList);
                        }
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                RealmHelper.getInstance().addMessagesFromJson(messageJsonArray, connectionPositionOnList);
                                listener.onMessagesReady();
                            }
                        });
                    }
                    subscribeToRoom(roomId);
                } catch (JSONException e) {
                    e.printStackTrace();
                    listener.onConnectivityError();
                }
            }

            @Override
            public void onError(String error, String reason, String details) {
                listener.onConnectivityError();
            }
        });
    }

    public void subscribeToRoom(final String roomId) {
        if (subscriptionId == null) {
            subscriptionId = meteor.subscribe("stream-room-messages", new Object[]{roomId, false}, new SubscribeListener() {
                @Override
                public void onSuccess() {
                    l("Subscribed ");
                }

                @Override
                public void onError(String error, String reason, String details) {
                    l("Subscribe ERROR + " + error + ", reason = " + reason + ", details = " + details);
                }
            });
        }
    }

    public void sendMessage(String messageId, String roomId, final String message, final float lat, final float lng
            , final ISendMessagesCallback listener) {
        C.L("trying to send message");
        try {
            if (!host.isValid()) {
                listener.onConnectivityError();
                return;
            }
            if (messageId == null) {
                messageId = UUID.randomUUID().toString();
            }
            if (liveChatRoomId.isEmpty()) {
                liveChatRoomId = roomId;
            } else {
                roomId = liveChatRoomId;
            }
            final String messageID = messageId;
            final JSONObject messageJsonObject = new JSONObject()
                    .put(C.JSON_FIELD_ID, messageId)
                    .put(C.JSON_FIELD_ROOM_ID, roomId)
                    .put(C.JSON_FIELD_MESSAGE, message)
                    .put(C.JSON_FIELD_POS_ON_THE_LIST, connectionPositionOnList)
                    .put(C.JSON_FIELD_SYNCSTATE, SyncState.SYNCING)
                    .put(C.JSON_FIELD_USER_SHORT, new JSONObject()
                            .put(C.JSON_FIELD_USERNAME, user.getUsername())
                            .put(C.JSON_FIELD_USER_ID, host.getLiveChatUserId()))
                    .put(C.JSON_FIELD_TIMESTAMP, System.currentTimeMillis());
            final MeteorMessage messageMeteor = new MeteorMessage();
            messageMeteor.setMsg(message);
            messageMeteor.setRid(roomId);
            messageMeteor.setId(messageId);
            if (lat != 0 && lng != 0) {
                messageMeteor.setPoint(lat, lng);
                messageJsonObject.put(C.JSON_FIELD_LOCATION, new JSONObject()
                        .put(C.JSON_FIELD_LOCATION_TYPE, C.JSON_VALUE_LOCATION_POINT)
                        .put(C.JSON_FIELD_LOCATION_LAT, lat)
                        .put(C.JSON_FIELD_LOCATION_LNG, lng));
            }
            RealmHelper.getInstance().addMessageFromJson(messageJsonObject);
            listener.onMessageStateUpdated();
            if (meteor.isConnected()) {
                meteor.call(C.RPC_SEND_MESSAGE, new Object[]{messageMeteor}, new ResultListener() {
                    @Override
                    public void onSuccess(String result) {
                        C.L("message Sent returned" + result);
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                RealmHelper.getInstance().updateMessageState(connectionPositionOnList, messageID, SyncState.SYNCED);
                                listener.onMessageStateUpdated();
                            }
                        });
                    }

                    @Override
                    public void onError(String error, String reason, String details) {
                        C.L("message Sent ERROR returned" + error + ", reason = " + reason + "details = " + details);
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                RealmHelper.getInstance().updateMessageState(connectionPositionOnList, messageID, SyncState.FAILED);
                                listener.onConnectivityError();
                            }
                        });
                    }
                });
            } else {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        RealmHelper.getInstance().updateMessageState(connectionPositionOnList, messageID, SyncState.FAILED);
                        listener.onConnectivityError();
                    }
                });
            }
        } catch (JSONException je) {
            je.printStackTrace();
            listener.onConnectivityError();
        }
    }

    public void sendFileMessage(final String storageType, final String roomId, final String downloadUrl, final long fileSize, final String mimeType, final String fileName, final String filePath, final ISendFileCallback listener) {
        C.L("trying to send file " + fileName);
        Task.callInBackground(new Callable<Object>() {
            @Override
            public Object call() throws Exception {
                C.L("FILEUPLOAD #5.0");
                String id = Uri.parse(downloadUrl).getLastPathSegment();
                C.L("ID=" + id);
                MeteorFileSendMessage fileSendMessageMeteor = new MeteorFileSendMessage();
                fileSendMessageMeteor.setSize(fileSize);
                fileSendMessageMeteor.setId(id);
                fileSendMessageMeteor.setType(mimeType);
                fileSendMessageMeteor.setUrl(downloadUrl);
                fileSendMessageMeteor.setName(fileName);
                meteor.call(C.RPC_SEND_FILE_MESSAGE, new Object[]{roomId, storageType, fileSendMessageMeteor}, new ResultListener() {
                    @Override
                    public void onSuccess(String result) {
                        listener.onFileSent(fileName, filePath);
                        l("ROCKETCHATUPLOAD SUCCESS = " + result);
                    }

                    @Override
                    public void onError(String error, String reason, String details) {
                        l("ROCKETCHATUPLOAD SEND FILE MESSAGE ERRORRRR = " + error + ", reason = " + reason + ", details = " + details);
                        if (reason.contains("File exceeds allowed size")) {
                            listener.onFileTooBigError(filePath);
                        } else {
                            listener.onConnectionError(filePath);
                        }
                    }
                });
                return null;
            }
        });
    }

    private void parseResultAndUpload(final File file, final String roomId, String result, final String filename, final String filePath, final long filesize, final String mimeType, final ISendFileCallback listener) {
        try {
            C.L("FILEUPLOAD #4.0");
            JSONObject info = new JSONObject(result);
            String uploadUrl = info.getString("upload");
            final String downloadUrl = info.getString("download");
            JSONArray postDataList = info.getJSONArray("postData");
            MultipartBody.Builder bodyBuilder = new MultipartBody.Builder().setType(MultipartBody.FORM);
            for (int i = 0; i < postDataList.length(); i++) {
                JSONObject postData = postDataList.getJSONObject(i);
                bodyBuilder.addFormDataPart(postData.getString("name"), postData.getString("value"));
            }
            C.L("FILEUPLOAD #4.1");
            bodyBuilder.addFormDataPart("file", filename,
                    new RequestBody() {
                        private long numBytes = 0;

                        @Override
                        public MediaType contentType() {
                            return MediaType.parse(mimeType);
                        }

                        @Override
                        public long contentLength() throws IOException {
                            return filesize;
                        }

                        @Override
                        public void writeTo(BufferedSink sink) throws IOException {
                            try {
                                C.L("FILEUPLOAD #4.2");
                                Source source = Okio.source(file);
                                long readBytes;
                                while ((readBytes = source.read(sink.buffer(), 8192)) > 0) {
                                    numBytes += readBytes;
                                }
                                sendFileMessage("s3", roomId, downloadUrl, filesize, mimeType, filename, filePath, listener);
                            } catch (FileNotFoundException e) {
                                e.printStackTrace();
                                listener.onInvalidFileType(filePath);
                            } catch (Exception e) {
                                e.printStackTrace();
                                listener.onConnectionError(filePath);
                            }
                        }
                    });
            C.L("FILEUPLOAD #4.3");
            final Request request = new Request.Builder()
                    .url(uploadUrl)
                    .post(bodyBuilder.build())
                    .build();
            Task.callInBackground(new Callable<Object>() {
                @Override
                public Object call() throws Exception {
                    Response response = OkHttpHelper.getClientForUploadFile().newCall(request).execute();
                    return null;
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
            C.L("FILEUPLOAD #4.4");
            listener.onConnectionError(filePath);
        }
    }

    private void initLiveChatSequence() {
        liveChatGetInitialData(new IChannelCreatedCallback() {
            @Override
            public void onChannelCreated(String roomId) {
                if (hostConnectionListener != null) {
                    hostConnectionListener.onConnectedAndLoggedIn();
                }
            }

            @Override
            public void onConnectivityError() {
                if (hostConnectionListener != null) {
                    hostConnectionListener.onConnectivityError();
                }
            }
        });
    }

    private void registerOrLogin(final IChannelCreatedCallback listener) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (host.isValid()) {
                    liveChatUserLoginToken = host.getLoginToken();
                    liveChatUserId = host.getLiveChatUserId();
                    liveChatRoomId = host.getRoomId();
                    RealmHelper.getInstance().executeCustomTransaction(new Realm.Transaction() {
                        @Override
                        public void execute(Realm realm) {
                            if (liveChatRoomId == null || liveChatRoomId.isEmpty()) {
                                liveChatRoomId = UUID.randomUUID().toString();
                            }
                            if (liveChatUserLoginToken == null || liveChatUserLoginToken.isEmpty()) {
                                liveChatRegisterGuest(liveChatToken, user.getUsername(), user.getEmail(), listener);
                            } else {
                                liveChatLoginGuest(liveChatUserLoginToken, liveChatUserId, listener);
                            }
                        }
                    });
                } else {
                    listener.onConnectivityError();
                }
            }
        });
    }

    public void liveChatGetInitialData(final IChannelCreatedCallback listener) {
        liveChatToken = UUID.randomUUID().toString();
        meteor.call("livechat:getInitialData", new Object[]{liveChatToken}, new ResultListener() {
            @Override
            public void onSuccess(String result) {
                l("livechat:getInitialData success = " + result);
                subscribeLoginServiceConfiguration(new SubscribeListener() {
                    @Override
                    public void onSuccess() {
                        l("meteor.loginServiceConfiguration");
                        registerOrLogin(listener);
                    }

                    @Override
                    public void onError(String error, String reason, String details) {
                        l("meteor.loginServiceConfiguration ERRORRRR = " + error + ", reason = " + reason + ", details = " + details);
                        listener.onConnectivityError();
                    }
                });
            }

            @Override
            public void onError(String error, String reason, String details) {
                l("livechat:getInitialData ERRORRRR = " + error + ", reason = " + reason + ", details = " + details);
                listener.onConnectivityError();
            }
        });
    }

    private void liveChatLoginGuest(final String newLiveChatUserLoginToken, final String newLiveChatUserId, final IChannelCreatedCallback listener) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                RealmHelper.getInstance().executeCustomTransaction(new Realm.Transaction() {
                    @Override
                    public void execute(Realm realm) {
                        if (!host.isValid()) {
                            listener.onConnectivityError();
                            return;
                        }
                        liveChatUserLoginToken = newLiveChatUserLoginToken;
                        host.setUserLoginToken(liveChatUserLoginToken);
                        host.setUserId(newLiveChatUserId);
                        realm.copyToRealmOrUpdate(host);
                        LiveChatResume liveChatResume = new LiveChatResume();
                        liveChatResume.setResume(liveChatUserLoginToken);
                        meteor.call("login", new Object[]{liveChatResume}, new ResultListener() {
                            @Override
                            public void onSuccess(String result) {
                                l("login success = " + result);
                                liveChatSendMessage("Hello", listener);
                            }

                            @Override
                            public void onError(String error, String reason, String details) {
                                l("login ERRORRRR = " + error + ", reason = " + reason + ", details = " + details);
                                listener.onConnectivityError();
                            }
                        });
                    }
                });
            }
        });
    }

    private void setUserIdsAndRoomIdsMap(Map<String, String> userIdAndRoomIdMap) {
        JSONObject jsonObject = new JSONObject(userIdAndRoomIdMap);
        String jsonObjectString = jsonObject.toString();
        PrefsHelper.getInstance().setString(C.PREFERENCES_MAP_USER_IDS_AND_ROOM_IDS, jsonObjectString);
    }

    private Map<String, String> retrieveUserIdsAndRoomIds() {
        String userIdsAndRoomIdsString = PrefsHelper.getInstance().getString(C.PREFERENCES_MAP_USER_IDS_AND_ROOM_IDS);
        try {
            HashMap<String, String> result = new ObjectMapper().readValue(userIdsAndRoomIdsString, HashMap.class);
            return result;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void liveChatRegisterGuest(String token, String userName, String email, final IChannelCreatedCallback listener) {
        LivechatUser user = new LivechatUser();
        user.setEmail(email);
        user.setName(userName);
        user.setToken(token);
        meteor.call("livechat:registerGuest", new Object[]{user}, new ResultListener() {
            @Override
            public void onSuccess(String result) {
                l("livechat:registerGuest success = " + result);
                LiveChatRegisterGuest liveChatRegisterGuest = new Gson().fromJson(result, LiveChatRegisterGuest.class);
                liveChatLoginGuest(liveChatRegisterGuest.getToken(), liveChatRegisterGuest.getUserId(), listener);
            }

            @Override
            public void onError(String error, String reason, String details) {
                l("livechat:registerGuest ERRORRRR = " + error + ", reason = " + reason + ", details = " + details);
                listener.onConnectivityError();
            }
        });
    }

    private String retrieveRoomIdForUserId() {
        String userId = ConnectionManager.getInstance().getUser().getAuth0Id();
        Map<String, String> userIdsAndRoomIds = retrieveUserIdsAndRoomIds();
        if (userIdsAndRoomIds != null) {
            Iterator iterator = userIdsAndRoomIds.entrySet().iterator();
            while (iterator.hasNext()) {
                Map.Entry<String, String> pair = (Map.Entry) iterator.next();
                if (pair != null && pair.getKey().equals(userId)) {
                    return pair.getValue();
                }
            }
        }
        return null;
    }

    private void setRoomIdForUserId(String roomId) {
        String userId = ConnectionManager.getInstance().getUser().getAuth0Id();
        Map<String, String> userIdsAndRoomIds = retrieveUserIdsAndRoomIds();
        if (userIdsAndRoomIds == null) {
            userIdsAndRoomIds = new HashMap<>();
        }
        userIdsAndRoomIds.put(userId, roomId);
        setUserIdsAndRoomIdsMap(userIdsAndRoomIds);
    }

    public void liveChatSendMessage(String message, final IChannelCreatedCallback listener) {
        if (liveChatRoomId.isEmpty()) {
            liveChatRoomId = UUID.randomUUID().toString();
        }
        subscriptionId = null;
        LiveChatMessage liveChatMessage = new LiveChatMessage();
        liveChatMessage.setToken(liveChatToken);
        liveChatMessage.setRid(liveChatRoomId);
        liveChatMessage.setMsg(message);
        liveChatMessage.setId(UUID.randomUUID().toString());
        String retrievedRoomId = retrieveRoomIdForUserId();
        if (retrievedRoomId != null) {
            liveChatRoomId = retrievedRoomId;
            updateRoomId(liveChatRoomId, listener);
            return;
        }
        meteor.call("sendMessageLivechat", new Object[]{liveChatMessage}, new ResultListener() {
            @Override
            public void onSuccess(String result) {
                l("sendMessageLivechat success = " + result);
                LiveChatMessage lcMessage = new Gson().fromJson(result, LiveChatMessage.class);
                liveChatRoomId = lcMessage.getRid();
                updateRoomId(liveChatRoomId, listener);
                setRoomIdForUserId(liveChatRoomId);
                listener.onChannelCreated(liveChatRoomId);
            }

            @Override
            public void onError(String error, String reason, String details) {
                l("sendMessageLivechat ERRORRRR = " + error + ", reason = " + reason + ", details = " + details);
                listener.onConnectivityError();
            }
        });
    }

    public void subscribeLoginServiceConfiguration(SubscribeListener subscribeListener) {
        meteor.subscribe("meteor.loginServiceConfiguration", new Object[]{null}, subscribeListener);
    }

    public void requestFileSpaceAndUpload(String roomId, final String filePath, final ISendFileCallback listener) {
        C.L("trying to send file");
        try {
            if (!host.isValid()) {
                listener.onConnectionError(filePath);
                return;
            }
            if (!liveChatRoomId.isEmpty()) {
                roomId = liveChatRoomId;
            }
            final JSONObject messageJsonObject = new JSONObject()
                    .put(C.JSON_FIELD_ID, filePath)
                    .put(C.JSON_FIELD_ROOM_ID, roomId)
                    .put(C.JSON_FIELD_MESSAGE, "")
                    .put(C.JSON_FIELD_POS_ON_THE_LIST, connectionPositionOnList)
                    .put(C.JSON_FIELD_SYNCSTATE, SyncState.SYNCING)
                    .put(C.JSON_FIELD_USER_SHORT, new JSONObject()
                            .put(C.JSON_FIELD_USERNAME, user.getUsername())
                            .put(C.JSON_FIELD_USER_ID, host.getLiveChatUserId()))
                    .put(C.JSON_FIELD_ATTACHMENTS, new JSONArray().put(new JSONObject().put(C.JSON_FIELD_TITLE, C.TITLE_VALUE_FILE).put(C.JSON_FIELD_TITLE_URL, filePath)))
                    .put(C.JSON_FIELD_TIMESTAMP, System.currentTimeMillis());
            RealmHelper.getInstance().addMessageFromJson(messageJsonObject);
            listener.onImageAddedToDatabase();
            C.L("FILEUPLOAD #1");
            final String roomId2 = roomId;
            Task.callInBackground(new Callable<Object>() {
                @Override
                public Object call() throws Exception {
                    C.L("FILEUPLOAD #2.0 filepath = " + filePath);
                    String[] pathSegments = filePath.split("/");
                    final String fileName = pathSegments[pathSegments.length - 1];
                    final String fileMimeType = ChatUtilities.getMimeType(filePath);
                    final File file = new File(filePath);
                    final long fileSize = file.length();
                    MeteorFile fileMeteor = new MeteorFile();
                    fileMeteor.setName(fileName);
                    fileMeteor.setSize(fileSize);
                    fileMeteor.setType(fileMimeType);
                    MeteorRoomId roomIdMeteor = new MeteorRoomId();
                    roomIdMeteor.setRid(roomId2);
                    if (meteor.isConnected()) {
                        meteor.call(C.RPC_UPLOAD_REQUEST, new Object[]{"rocketchat-uploads", fileMeteor, roomIdMeteor}, new ResultListener() {
                            @Override
                            public void onSuccess(String result) {
                                l("ROCKETCHATUPLOAD success = " + result);
                                parseResultAndUpload(file, roomId2, result, fileName, filePath, fileSize, fileMimeType, listener);
                            }

                            @Override
                            public void onError(String error, String reason, String details) {
                                l("ROCKETCHATUPLOAD ERRORRRR = " + error + ", reason = " + reason + ", details = " + details);
                                if (error != null && error.contains("File exceeds allowed size")) {
                                    listener.onFileTooBigError(filePath);
                                } else if (error != null && error.contains("Invalid file type")) {
                                    listener.onInvalidFileType(filePath);
                                } else {
                                    listener.onServerError(filePath);
                                }
                            }
                        });
                    } else {
                        listener.onConnectionError(filePath);
                    }
                    return null;
                }
            });
        } catch (JSONException e) {
            C.L("FILEUPLOAD #1.1");
            e.printStackTrace();
            listener.onConnectionError(filePath);
        }
    }

    @Override
    public void onConnect(boolean signedInAutomatically) {
        l("onConnect");
        initLiveChatSequence();
    }

    @Override
    public void onDisconnect() {
        l("onDisconnect");
        if (hostConnectionListener != null) {
            hostConnectionListener.onDisconnected();
        }
        subscriptionId = null;
    }

    @Override
    public void onException(Exception e) {
        l("onException = " + e.getMessage());
    }

    @Override
    public void onDataAdded(String collectionName, String documentID, String newValuesJson) {
        l("onDataAdded collectionName = " + collectionName + ", documentID = " + documentID + ", newValuesJson = " + newValuesJson);
    }

    @Override
    public void onDataChanged(String collectionName, String documentID, String updatedValuesJson, String removedValuesJson) {
        l("onDataAdded collectionName = " + collectionName + ", documentID = " + documentID + ", updatedValuesJson = " + updatedValuesJson + ", removedValuesJson = " + removedValuesJson);
        String moddedJsonString = RegexHelper.simplifyDate(updatedValuesJson);
        moddedJsonString = RegexHelper.simplifyLocation(moddedJsonString);
        try {
            JSONObject jsonObject = new JSONObject(moddedJsonString);
            if (jsonObject.has(C.JSON_FIELD_ARGS)) {
                JSONArray args = jsonObject.getJSONArray(C.JSON_FIELD_ARGS);
                if (args.length() > 0) {
                    RealmHelper.getInstance().addMessageFromJson(args.getJSONObject(0));
                    hostConnectionListener.onNewMessage();
                }
            }
        } catch (JSONException je) {
            je.printStackTrace();
        }
    }

    public void downloadOrOpenFileFromAttachment(final Context context, MessageAttachment attachment, final String token, final String userId) {
        String fileLink = attachment.getTitleLink();
        if (fileLink.startsWith("/")) {
            fileLink = fileLink.substring(1, fileLink.length());
        }
        final String url = ConnectionManager.getInstance().getHostConnectionForPos(connectionPositionOnList).getHost().getHostRocketChatApiUrl().concat(fileLink);
        downloadOrOpenFileFormUrl(context, url, userId, token);
    }

    public void downloadOrOpenFileFormUrl(final Context context, final String url, final String userId, final String token) {
        l("FILE URL = " + url);
        handler.post(new Runnable() {
            @Override
            public void run() {
                FileHelper.downloadOrOpenFileFromUrl(context, url, userId, token);
            }
        });
    }

    public void resendMessage(String filePath, Message message, final ISendFileCallback fileListener, final ISendMessagesCallback listener) {
        if (filePath == null) {
            float lat = 0;
            float lng = 0;
            if (message.getLocation() != null) {
                lat = message.getLocation().getLat();
                lng = message.getLocation().getLng();
            }
            sendMessage(message.getId(), message.getRoomId(), message.getMessage(), lat, lng, listener);
        } else {
            requestFileSpaceAndUpload(message.getRoomId(), filePath, fileListener);
        }
    }

    public void resendUnsynchronizedMessages(ISendMessagesCallback messaageListener, ISendFileCallback fileListener) {
        List<Message> messageList = RealmHelper.getInstance().getUnsentMessages(connectionPositionOnList);
        for (Message message : messageList) {
            String filePath = null;
            if (message.getAttachments() != null) {
                for (MessageAttachment attachment : message.getAttachments()) {
                    if (attachment.getTitle().contains(C.TITLE_VALUE_FILE) && !attachment.getTitleUrl().isEmpty()) {
                        filePath = attachment.getTitleUrl();
                    }
                }
            }
            resendMessage(filePath, message, fileListener, messaageListener);
        }
    }

    @Override
    public void onDataRemoved(String collectionName, String documentID) {
        l("onDataRemoved collectionName = " + collectionName + ", documentID = " + documentID);
    }

    private void l(String l) {
        Log.e("DDP_ROCKET_CHAT = ", l);
    }

    public Host getHost() {
        return host;
    }

    public interface ISendFileCallback {
        void onFileSent(String name, String filePath);

        void onImageAddedToDatabase();

        void onFileTooBigError(String filePath);

        void onConnectionError(String filePath);

        void onInvalidFileType(String filePath);

        void onServerError(String filePath);
    }

    interface IBaseErrorCallback {
        void onConnectivityError();
    }

    public interface IChannelCreatedCallback extends IBaseErrorCallback {
        void onChannelCreated(String roomId);
    }

    public interface IGetMessagesCallback extends IBaseErrorCallback {
        void onMessagesReady();
    }

    public interface ISendMessagesCallback extends IBaseErrorCallback {
        void onMessageStateUpdated();
    }

    public interface IResetPasswordCallback extends IBaseErrorCallback {
        void onPasswordReset();
    }

    public interface IHostConnectionCallback extends IBaseErrorCallback {
        void onDisconnected();

        void onConnectedAndLoggedIn();

        void onNewMessage();
    }
}
