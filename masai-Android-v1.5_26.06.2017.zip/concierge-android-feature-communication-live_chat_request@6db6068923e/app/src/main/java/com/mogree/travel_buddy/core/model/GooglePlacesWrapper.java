package com.mogree.travel_buddy.core.model;

/**
 * Created by Semko on 2016-12-21.
 */

public class GooglePlacesWrapper {
    private GooglePlace[] results;

    public GooglePlace[] getResults() {
        return results;
    }
}
