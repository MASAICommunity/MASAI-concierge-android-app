package com.mogree.travel_buddy.my_tickets;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.model.Reservations;
import com.mogree.travel_buddy.core.model.TravelSegment;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MyTicketsController extends AppCompatActivity implements MyTicketsView.MyTicketsViewListener {
    private MyTicketsView view;
    private MyTicketsAdapter myTicketsAdapter;
    private Context context;
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.context = this;
        handler = new Handler(Looper.getMainLooper());
        setContentView(R.layout.activity_my_tickets);
        view = new MyTicketsView(findViewById(android.R.id.content), this, this);
        String json = readJson();
        json = json.replace("\"\"", "null");
        Reservations reservations = getReservations(json);
        List<TravelSegment> reservationsAndTickets = getHotelReservations(reservations);
        myTicketsAdapter = new MyTicketsAdapter(this, reservationsAndTickets);
        view.setMyTicketsAdapter(myTicketsAdapter);
        view.setTitle(getString(R.string.nav_tickets));
    }

    private List<TravelSegment> getHotelReservations(Reservations reservations) {
        List<TravelSegment> hotelReservations = new ArrayList<>();
        for (Reservations.TravelItem item : reservations.getItems()) {
            if (item.getSegments() != null) {
                for (TravelSegment travelSegment : item.getSegments()) {
                    if (travelSegment.getHotelReservation() != null || travelSegment.getFlight() != null || travelSegment.getPublicTransportation() != null) {
                        hotelReservations.add(travelSegment);
                    }
                }
            }
            if (item.getPublicTransportation() != null) {
                TravelSegment segment = new TravelSegment();
                segment.setPublicTransportation(item.getPublicTransportation());
                hotelReservations.add(segment);
            }
            if (item.getFlight() != null) {
                TravelSegment segment = new TravelSegment();
                segment.setFlight(item.getFlight());
                hotelReservations.add(segment);
            }
            if (item.getHotelReservation() != null) {
                TravelSegment segment = new TravelSegment();
                segment.setHotelReservation(item.getHotelReservation());
                hotelReservations.add(segment);
            }
        }
        return hotelReservations;
    }

    private Reservations getReservations(String json) {
        Reservations reservations = null;
        if (json != null) {
            Gson gson = new GsonBuilder().serializeNulls().create();
            reservations = gson.fromJson(json, Reservations.class);
        }
        return reservations;
    }

    private String readJson() {
        try {
            StringBuilder buf = new StringBuilder();
            InputStream json = getAssets().open("journey.json");
            BufferedReader in = new BufferedReader(new InputStreamReader(json, "UTF-8"));
            String str;
            while ((str = in.readLine()) != null) {
                buf.append(str);
            }
            in.close();
            return buf.toString();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onStop() {
        view.hideProgress();
        super.onStop();
    }

    @Override
    public void onNavigateBack() {
        onBackPressed();
    }
}
