package com.mogree.travel_buddy.public_transportation;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.gson.Gson;
import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.helper.C;
import com.mogree.travel_buddy.core.model.Reservations;

public class PublicTransportationController extends AppCompatActivity implements PublicTransportationView.PublicTransportationViewListener {
    private PublicTransportationView view;
    private Context context;
    private Handler handler;
    private MapView mapView;
    private GoogleMap map;
    private Reservations.PublicTransportation publicTransportation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.context = this;
        handler = new Handler(Looper.getMainLooper());
        setContentView(R.layout.activity_train_ticket);
        readPublicTransportation(getIntent());
        view = new PublicTransportationView(findViewById(android.R.id.content), this, this);
        String departureName = publicTransportation.getDeparture().getStationName();
        String arrivalName = publicTransportation.getArrival().getStationName();
        if (departureName == null) {
            departureName = "";
        }
        if (arrivalName == null) {
            arrivalName = "";
        }
        String sourceDestination = departureName.concat(" - ").concat(arrivalName);
        view.setTitle(sourceDestination);
        view.setInfo(publicTransportation);
    }

    public void readPublicTransportation(Intent intent) {
        String reservationJSON = intent.getStringExtra(C.EXTRA_TRAIN);
        publicTransportation = new Gson().fromJson(reservationJSON, Reservations.PublicTransportation.class);
    }

    @Override
    protected void onStop() {
        view.hideProgress();
        super.onStop();
    }

    @Override
    public void onNavigateBack() {
        onBackPressed();
    }

}
