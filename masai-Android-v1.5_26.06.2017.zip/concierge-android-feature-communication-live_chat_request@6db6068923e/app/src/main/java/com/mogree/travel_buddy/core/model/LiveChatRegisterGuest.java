package com.mogree.travel_buddy.core.model;

/**
 * Created by Semko on 2017-04-10.
 */

public class LiveChatRegisterGuest {
    private String token = "";
    private String userId = "";

    public String getUserId() {
        return userId;
    }

    public String getToken() {
        return token;
    }
}
