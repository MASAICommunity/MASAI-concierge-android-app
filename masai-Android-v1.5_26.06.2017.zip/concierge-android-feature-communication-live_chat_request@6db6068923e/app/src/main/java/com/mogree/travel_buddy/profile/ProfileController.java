package com.mogree.travel_buddy.profile;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.communication.ConnectionManager;
import com.mogree.travel_buddy.core.model.User;

public class ProfileController extends AppCompatActivity implements ProfileView.ProfileViewListener {
    ProfileView view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_view);
        view = new ProfileView(findViewById(android.R.id.content), this, this);
        User user = ConnectionManager.getInstance().getUser();
        view.setTravelfolderWebViewData(user.getIdToken());
    }

    @Override
    public void onBackArrowPressed() {
        onBackPressed();
    }

    @Override
    public void onUpdate(String name, String password) {
        view.showProgress();
    }
}