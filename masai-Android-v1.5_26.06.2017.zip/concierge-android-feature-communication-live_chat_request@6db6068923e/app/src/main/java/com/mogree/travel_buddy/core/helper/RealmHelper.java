package com.mogree.travel_buddy.core.helper;

import android.content.Context;

import com.mogree.travel_buddy.core.communication.ConnectionManager;
import com.mogree.travel_buddy.core.model.Host;
import com.mogree.travel_buddy.core.model.Message;
import com.mogree.travel_buddy.core.model.MessageAttachment;
import com.mogree.travel_buddy.core.model.SyncState;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import io.realm.Realm;
import io.realm.RealmChangeListener;
import io.realm.RealmConfiguration;
import io.realm.RealmResults;

/**
 * Created by Semko on 2016-12-06.
 */

public class RealmHelper {
    private static RealmHelper instance;

    public static RealmHelper getInstance() {
        if (instance == null) {
            instance = new RealmHelper();
        }
        return instance;
    }

    public void init(Context context) {
        Realm.init(context);
        RealmConfiguration config = new RealmConfiguration.Builder().deleteRealmIfMigrationNeeded().build();
        Realm.setDefaultConfiguration(config);
    }

    private long getNextKey(Realm realm, Class c) {
        Number mid = realm.where(c).max("id");
        if (mid != null) {
            return mid.longValue() + 1;
        }
        return 0;
    }

    public void drop() {
        Realm realm = Realm.getDefaultInstance();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                realm.deleteAll();
            }
        });
    }

    public void executeCustomTransaction(Realm.Transaction transaction) {
        Realm realm = Realm.getDefaultInstance();
        realm.executeTransaction(transaction);
    }

    public void removeHost(final long id) {
        Realm realm = Realm.getDefaultInstance();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                Host host = realm.where(Host.class).equalTo("id", id).findFirst();
                if (host != null) {
                    host.deleteFromRealm();
                }
            }
        });
    }

    public Host addHost(final Host host) {
        Realm realm = Realm.getDefaultInstance();
        realm.beginTransaction();
        Host realmHost = realm.createObject(Host.class, getNextKey(realm, Host.class));
        realmHost.setHumanName(host.getHumanName());
        realmHost.setHostUrl(host.getHostUrl());
        realmHost.setHostRocketChatApiUrl(host.getHostRocketChatApiUrl());
        realm.commitTransaction();
        return realmHost;
    }

    public void updateHost(final Host host) {
        Realm realm = Realm.getDefaultInstance();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                realm.copyToRealmOrUpdate(host);
            }
        });
    }

    public Host[] getHostConnectionListListener(RealmChangeListener<RealmResults<Host>> listener) {
        Realm realm = Realm.getDefaultInstance();
        final RealmResults<Host> conversationList = realm.where(Host.class).findAll();
        conversationList.addChangeListener(listener);
        Host[] hosts = conversationList.toArray(new Host[]{});
        return hosts;
    }

    public List<Message> getMessages(int pos) {
        String roomId = ConnectionManager.getInstance().getHostConnectionForPos(pos).getHost().getRoomId();
        Realm realm = Realm.getDefaultInstance();
        final RealmResults<Message> messages = realm.where(Message.class).equalTo(C.JSON_FIELD_ROOM_ID, roomId).findAllSorted(C.JSON_FIELD_TIMESTAMP);
        return messages.subList(0, messages.size());
    }

    public List<Message> getUnsentMessages(int pos) {
        String roomId = ConnectionManager.getInstance().getHostConnectionForPos(pos).getHost().getRoomId();
        Realm realm = Realm.getDefaultInstance();
        final RealmResults<Message> messages = realm.where(Message.class).equalTo(C.JSON_FIELD_ROOM_ID, roomId)
                .equalTo(C.JSON_FIELD_SYNCSTATE, SyncState.FAILED).findAllSorted(C.JSON_FIELD_TIMESTAMP);
        return messages.subList(0, messages.size());
    }

    public Message getFirstMessage(int pos) {
        C.L("getFirstMessage for POS=" + Integer.toString(pos));
        String roomId = ConnectionManager.getInstance().getHostConnectionForPos(pos).getHost().getRoomId();
        Realm realm = Realm.getDefaultInstance();
        final RealmResults<Message> messages = realm.where(Message.class).equalTo(C.JSON_FIELD_ROOM_ID, roomId).findAllSorted(C.JSON_FIELD_TIMESTAMP);
        if (messages.size() == 0) {
            return null;
        } else {
            return messages.get(0);
        }
    }

    public Message getLatestMessage(int pos) {
        C.L("getLatestMessage for POS=" + Integer.toString(pos));
        Realm realm = Realm.getDefaultInstance();
        String roomId = ConnectionManager.getInstance().getHostConnectionForPos(pos).getHost().getRoomId();
        final RealmResults<Message> messages = realm.where(Message.class).equalTo(C.JSON_FIELD_ROOM_ID, roomId).findAllSorted(C.JSON_FIELD_TIMESTAMP);
        if (messages.size() == 0) {
            return null;
        } else {
            return messages.get(messages.size() - 1);
        }
    }

    public void removeDuplicateImageMessages(final int pos, final IMessageRemovedListener listener) {
        C.L("removeDuplicateImageMessages for POS=" + Integer.toString(pos));
        final String roomId = ConnectionManager.getInstance().getHostConnectionForPos(pos).getHost().getRoomId();
        Realm realm = Realm.getDefaultInstance();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                List<String> messageIdsToRemove = new ArrayList<>();
                final RealmResults<Message> messagesWithAttachments = realm.where(Message.class).equalTo(C.JSON_FIELD_ROOM_ID, roomId)
                        .isNotNull(C.JSON_FIELD_ATTACHMENTS).findAll();
                for (Message localFileMessage : messagesWithAttachments) {
                    if (localFileMessage.hasAttachments() && (localFileMessage.getSyncstate() == SyncState.SYNCING || localFileMessage.getSyncstate() == SyncState.FAILED)) {
                        for (MessageAttachment localFileMessageAttachment : localFileMessage.getAttachments()) {
                            String fileName = null;
                            if (localFileMessageAttachment.getImageUrl() != null && !localFileMessageAttachment.getImageUrl().isEmpty()) {
                                String[] pathSegments = localFileMessageAttachment.getImageUrl().split("/");
                                fileName = pathSegments[pathSegments.length - 1];
                            }
                            if (localFileMessageAttachment.getTitleLink() != null && !localFileMessageAttachment.getTitleLink().isEmpty()) {
                                String[] pathSegments = localFileMessageAttachment.getTitleLink().split("/");
                                fileName = pathSegments[pathSegments.length - 1];
                            }
                            if (localFileMessageAttachment.getTitleUrl() != null && !localFileMessageAttachment.getTitleUrl().isEmpty()) {
                                String[] pathSegments = localFileMessageAttachment.getTitleUrl().split("/");
                                fileName = pathSegments[pathSegments.length - 1];
                            }
                            if (fileName != null) {
                                for (Message syncedFileMessage : messagesWithAttachments) {
                                    if (syncedFileMessage.hasAttachments() && (syncedFileMessage.getSyncstate() == SyncState.SYNCED || syncedFileMessage.getSyncstate() == SyncState.NOT_SYNCED)) {
                                        for (MessageAttachment syncedFileMessageAttachment : syncedFileMessage.getAttachments()) {
                                            String syncedUrl = null;
                                            if (syncedFileMessageAttachment.getImageUrl() != null && !syncedFileMessageAttachment.getImageUrl().isEmpty()) {
                                                syncedUrl = syncedFileMessageAttachment.getImageUrl();
                                            }
                                            if (syncedFileMessageAttachment.getTitleLink() != null && !syncedFileMessageAttachment.getTitleLink().isEmpty()) {
                                                syncedUrl = syncedFileMessageAttachment.getTitleLink();
                                            }
                                            if (syncedUrl != null) {
                                                if (syncedUrl.contains(fileName)) {
                                                    if (!messageIdsToRemove.contains(localFileMessage.getId())) {
                                                        messageIdsToRemove.add(localFileMessage.getId());
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                for (String messageIdToRemove : messageIdsToRemove) {
                    final RealmResults<Message> conversationList = realm.where(Message.class).equalTo(C.JSON_FIELD_ROOM_ID, roomId).equalTo(C.JSON_FIELD_ID, messageIdToRemove).findAll();
                    for (Message message : conversationList) {
                        message.deleteFromRealm();
                    }
                }
                if (messageIdsToRemove.size() > 0) {
                    listener.messageRemoved();
                }
            }
        });
    }

    public interface IMessageRemovedListener {
        void messageRemoved();
    }

    public void removeMessageWithId(final int pos, final String messageID) {
        C.L("updateMessageState for POS=" + Integer.toString(pos));
        final String roomId = ConnectionManager.getInstance().getHostConnectionForPos(pos).getHost().getRoomId();
        Realm realm = Realm.getDefaultInstance();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                final RealmResults<Message> conversationList = realm.where(Message.class).equalTo(C.JSON_FIELD_ROOM_ID, roomId).equalTo(C.JSON_FIELD_ID, messageID).findAll();
                for (Message message : conversationList) {
                    message.deleteFromRealm();
                }
            }
        });
    }

    public void addMessageFromJson(final JSONObject json) {
        Realm realm = Realm.getDefaultInstance();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                realm.createOrUpdateObjectFromJson(Message.class, json);
            }
        });
    }

    public void updateMessageState(final int pos, final String messageID, final int syncState) {
        C.L("updateMessageState for POS=" + Integer.toString(pos));
        final String roomId = ConnectionManager.getInstance().getHostConnectionForPos(pos).getHost().getRoomId();
        Realm realm = Realm.getDefaultInstance();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                final RealmResults<Message> conversationList = realm.where(Message.class).equalTo(C.JSON_FIELD_ROOM_ID, roomId).equalTo(C.JSON_FIELD_ID, messageID).findAll();
                for (Message message : conversationList) {
                    message.setSyncstate(syncState);
                    realm.copyToRealmOrUpdate(message);
                }
            }
        });
    }

    public void updateMessageRequestPermissionState(final int pos, final String messageID, final boolean state) {
        C.L("updateMessage RequestPermissionState for POS=" + Integer.toString(pos));
        final String roomId = ConnectionManager.getInstance().getHostConnectionForPos(pos).getHost().getRoomId();
        Realm realm = Realm.getDefaultInstance();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                final RealmResults<Message> conversationList = realm.where(Message.class).equalTo(C.JSON_FIELD_ROOM_ID, roomId).equalTo(C.JSON_FIELD_ID, messageID).findAll();
                for (Message message : conversationList) {
                    message.setPermissionConfirmed(state);
                    realm.copyToRealmOrUpdate(message);
                }
            }
        });
    }

    public void addMessagesFromJson(final JSONArray jsonArray, int pos) {
        C.L("addMessagesFromJson for POS=" + Integer.toString(pos));
        Realm realm = Realm.getDefaultInstance();
        realm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                realm.createOrUpdateAllFromJson(Message.class, jsonArray);
            }
        });
    }
}
