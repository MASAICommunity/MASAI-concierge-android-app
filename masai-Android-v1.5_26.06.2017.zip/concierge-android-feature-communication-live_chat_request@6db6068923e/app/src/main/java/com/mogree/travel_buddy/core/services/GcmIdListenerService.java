package com.mogree.travel_buddy.core.services;

import android.content.Context;

import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.google.android.gms.iid.InstanceID;
import com.google.android.gms.iid.InstanceIDListenerService;
import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.helper.C;

import java.io.IOException;

/**
 * Created by Semko on 2016-12-15.
 */

public class GcmIdListenerService extends InstanceIDListenerService {
    @Override
    public void onTokenRefresh() {
        try {
            Context context = getApplicationContext();
            InstanceID instanceID = InstanceID.getInstance(context);
            String token = instanceID.getToken(context.getString(R.string.gcm_defaultSenderId), GoogleCloudMessaging.INSTANCE_ID_SCOPE, null);
            C.L("PUSH on token refresh " + token);
        } catch (IOException e) {
            e.printStackTrace();
        }
        super.onTokenRefresh();
    }
}
