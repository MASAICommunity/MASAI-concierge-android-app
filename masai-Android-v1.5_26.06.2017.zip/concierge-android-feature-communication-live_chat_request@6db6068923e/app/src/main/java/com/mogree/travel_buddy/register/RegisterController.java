package com.mogree.travel_buddy.register;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.communication.Auth0Helper;
import com.mogree.travel_buddy.core.communication.ConnectionManager;

public class RegisterController extends AppCompatActivity implements RegisterView.LoginViewListener, ConnectionManager.IConnectListener {
    private RegisterView view;
    private Handler handler = new Handler(Looper.getMainLooper());
    private Context context;
    private boolean successfullyRegistered = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = this;
        setContentView(R.layout.activity_register);
        view = new RegisterView(findViewById(android.R.id.content), this, this);
    }

    private void startConversationsController() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        });
    }

    @Override
    public void onContinueRegister(final String email, final String name, final String password) {
        view.showProgress();
        Auth0Helper.getInstance().singUp(email, password, name, new Auth0Helper.ISingUp() {
            @Override
            public void onBadUser() {
                view.showUsernameTakenError();
                view.hideProgress();
            }

            @Override
            public void onSingedUp() {
                if (ConnectionManager.getInstance().getHostConnectionList().size() == 0) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            ConnectionManager.getInstance().addConnection(context, 0, true, RegisterController.this);
                        }
                    });
                }
            }

            @Override
            public void onSingUpError() {
                view.showConnectivityError();
                view.hideProgress();
            }
        });
    }

    @Override
    protected void onPause() {
        if (!successfullyRegistered) {
            ConnectionManager.getInstance().setUser(null);
            while (ConnectionManager.getInstance().getHostConnectionList().size() > 0) {
                ConnectionManager.getInstance().removeConnection(0);
            }
        }
        super.onPause();
    }

    @Override
    public void onBackClicked() {
        onBackPressed();
    }

    @Override
    public void onDisconnected(int pos) {
        view.showConnectivityError();
        view.hideProgress();
    }

    @Override
    public void onConnectedAndLoggedIn(int pos) {
        startConversationsController();
        successfullyRegistered = true;
    }

    @Override
    public void onBadPassword(int pos) {

    }

    @Override
    public void onUserNotFound(int pos) {

    }

    @Override
    public void onNoUsername(int pos) {

    }

    @Override
    public void onNewMessage(int pos) {

    }

    @Override
    public void onConnectivityError(int pos) {
        view.showConnectivityError();
        view.hideProgress();
    }
}
