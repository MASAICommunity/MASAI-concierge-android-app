package com.mogree.travel_buddy.conversations;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;

import com.crashlytics.android.Crashlytics;
import com.embiq.communicationmanager.CommunicationManager;
import com.google.firebase.iid.FirebaseInstanceId;
import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.add_host.AddHostController;
import com.mogree.travel_buddy.chat.ChatController;
import com.mogree.travel_buddy.core.communication.Auth0Helper;
import com.mogree.travel_buddy.core.communication.ConnectionManager;
import com.mogree.travel_buddy.core.communication.HostConnection;
import com.mogree.travel_buddy.core.helper.C;
import com.mogree.travel_buddy.core.helper.ConnectivityChangeReceiver;
import com.mogree.travel_buddy.core.helper.DialogHelper;
import com.mogree.travel_buddy.core.helper.PrefsHelper;
import com.mogree.travel_buddy.core.helper.RealmHelper;
import com.mogree.travel_buddy.login.LoginController;
import com.mogree.travel_buddy.my_tickets.MyTicketsController;
import com.mogree.travel_buddy.profile.ProfileController;

import java.util.List;

import io.fabric.sdk.android.Fabric;

public class ConversationsController extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, ConversationsView.ConversationsViewListener, ConnectionManager.IConnectListener, ConnectivityChangeReceiver.INetworkState {
    private ConversationListAdapter conversationListAdapter;
    private ConversationsView view;
    private Handler handler;
    private boolean shouldTryAgain = true;
    private ConnectivityChangeReceiver connectivityChangeReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Fabric.with(this, new Crashlytics());
        setContentView(R.layout.activity_main);
        initCore();
        C.L("Token refreshed = " + FirebaseInstanceId.getInstance().getToken());
        view = new ConversationsView(this, this);
        conversationListAdapter = new ConversationListAdapter(this);
        view.setConnectionListAdapter(conversationListAdapter);
        CommunicationManager.setContext(getApplicationContext());
        handler = new Handler(Looper.getMainLooper());
        if (getIntent().hasExtra(C.EXTRA_ROOM_ID)) {
            startChat(0);
        }
    }

    @Override
    protected void onPause() {
        handler.removeCallbacksAndMessages(null);
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (connectivityChangeReceiver != null) {
            unregisterReceiver(connectivityChangeReceiver);
            connectivityChangeReceiver = null;
        }
    }

    private void initCore() {
        PrefsHelper.init(this);
        RealmHelper.getInstance().init(this.getApplicationContext());
    }

    @Override
    protected void onResume() {
        super.onResume();
        connectivityChangeReceiver = ConnectivityChangeReceiver.registerNetworkStateReceiver(this, this);
        configureUser();
        view.refreshList(conversationListAdapter);
    }

    private void configureUser() {
        if (ConnectionManager.getInstance().getUser() == null) {
            launchLogin();
        } else {
            if (ConnectionManager.getInstance().getHostConnectionList().size() < 1) {
                goToAddHostActivity();
            } else {
                C.L("TRYING TO CONNECT TO ALL");
                ConnectionManager.getInstance().connectToAll(this, this);
            }
        }
    }

    private void launchLogin() {
        Intent login = new Intent(getApplicationContext(), LoginController.class);
        startActivity(login);
    }

    private void launchProfile() {
        Intent profile = new Intent(getApplicationContext(), ProfileController.class);
        startActivity(profile);
    }

    private void launchTickets() {
        Intent profile = new Intent(getApplicationContext(), MyTicketsController.class);
        startActivity(profile);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.nav_profile) {
            launchProfile();
        } else if (id == R.id.nav_tickets) {
            launchTickets();
        } else if (id == R.id.nav_settings) {
            DialogHelper.dialogOk(this, R.string.feature_coming_soon);
        } else if (id == R.id.nav_help) {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("message/rfc822");
            i.putExtra(Intent.EXTRA_EMAIL, new String[]{C.HELP_UND_FEEDBACK_EMAIL});
            i.putExtra(Intent.EXTRA_SUBJECT, getString(R.string.help_and_feedback));
            startActivity(Intent.createChooser(i, "Send mail..."));
        } else if (id == R.id.nav_logout) {
            ConnectionManager.getInstance().removeAll();
            ConnectionManager.getInstance().setUser(null);
            ConnectionManager.clear();
            Auth0Helper.clear();
            PrefsHelper.getInstance().removePref(C.PREFERENCES_KEY_USER);
            launchLogin();
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    public void goToAddHostActivity() {
        Intent addHost = new Intent(getApplicationContext(), AddHostController.class);
        startActivity(addHost);
    }

    @Override
    public void onGoToAddHostController() {
        goToAddHostActivity();
    }

    private void startChat(int position) {
        if (getIntent().hasExtra(C.EXTRA_ROOM_ID)) {
            String roomId = getIntent().getStringExtra(C.EXTRA_ROOM_ID);
            List<HostConnection> hostConnectionList = ConnectionManager.getInstance().getHostConnectionList();
            for (int co0 = 0; co0 < hostConnectionList.size(); ++co0) {
                if (hostConnectionList.get(co0).getHost().getRoomId().equals(roomId)) {
                    position = co0;
                }
            }
        }
        Intent openConversation = new Intent(this, ChatController.class);
        openConversation.putExtra(C.EXTRA_HOST_CONNECTION_POSITION, position);
        startActivity(openConversation);
    }

    @Override
    public void onConnectionSelected(final int position) {
        startChat(position);
    }

    @Override
    public void onDisconnected(int pos) {
        ConnectionManager.setShouldShowInfoReconnecting(true);
        if (shouldTryAgain) {
            shouldTryAgain = false;
            configureUser();
        }
    }

    @Override
    public void onConnectedAndLoggedIn(final int pos) {
        if (ConnectionManager.isShouldShowInfoReconnecting()) {
            view.showInfoReconnecting();
            ConnectionManager.setShouldShowInfoReconnecting(false);
        }
        shouldTryAgain = true;
        handler.post(new Runnable() {
            @Override
            public void run() {
                view.setNavigationHeader();
                ConnectionManager.getInstance().getHostConnectionForPos(pos).liveChatGetInitialData(new HostConnection.IChannelCreatedCallback() {
                    @Override
                    public void onChannelCreated(final String roomId) {
                        handler.post(new Runnable() {
                            @Override
                            public void run() {
                                ConnectionManager.getInstance().getHostConnectionForPos(pos).loadMessagesFromWhileIWasAway(roomId, new HostConnection.IGetMessagesCallback() {
                                    @Override
                                    public void onMessagesReady() {
                                        view.refreshList(conversationListAdapter);
                                    }

                                    @Override
                                    public void onConnectivityError() {
                                    }
                                });
                            }
                        });
                    }

                    @Override
                    public void onConnectivityError() {

                    }
                });
            }
        });
    }

    @Override
    public void onBadPassword(int pos) {
    }

    @Override
    public void onUserNotFound(int pos) {
    }

    @Override
    public void onNoUsername(int pos) {
    }

    @Override
    public void onNewMessage(int pos) {
        view.refreshList(conversationListAdapter);
    }

    @Override
    public void onConnectivityError(int pos) {
    }

    @Override
    public void onStateConnected() {
        configureUser();
    }
}
