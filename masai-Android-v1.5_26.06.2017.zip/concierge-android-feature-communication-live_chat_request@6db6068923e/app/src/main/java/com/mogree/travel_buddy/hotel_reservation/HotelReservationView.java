package com.mogree.travel_buddy.hotel_reservation;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.helper.TimeHelper;
import com.mogree.travel_buddy.core.model.Reservations;

/**
 * Created by Semko on 2016-12-05.
 */

public class HotelReservationView {
    private View rootView;
    private HotelReservationViewListener listener;
    private Context context;
    private Handler handler;
    private TextView tvTitle;
    private TextView tvCheckIn;
    private TextView tvCheckOut;
    private TextView tvDuration;
    private TextView tvHotelAddress;
    private TextView tvConfirmationNumber;
    private TextView tvPhone;
    private TextView tvMail;
    private ImageView ivBack;
    private ProgressDialog progressDialog;

    HotelReservationView(View rootView, Context context, HotelReservationViewListener listener) {
        this.rootView = rootView;
        this.context = context;
        this.listener = listener;
        handler = new Handler(Looper.getMainLooper());
        initViews();
    }

    private void initViews() {
        progressDialog = new ProgressDialog(context, ProgressDialog.STYLE_SPINNER);
        progressDialog.setMessage(rootView.getContext().getString(R.string.loading_data));
        progressDialog.setCanceledOnTouchOutside(false);
        tvTitle = (TextView) rootView.findViewById(R.id.activity_hotel_reservation_ala_action_bar_title);
        tvCheckIn = (TextView) rootView.findViewById(R.id.hotel_check_in);
        tvCheckOut = (TextView) rootView.findViewById(R.id.hotel_check_out);
        tvDuration = (TextView) rootView.findViewById(R.id.hotel_duration);
        tvConfirmationNumber = (TextView) rootView.findViewById(R.id.hotel_confirmation_number);
        tvHotelAddress = (TextView) rootView.findViewById(R.id.hotel_address);
        tvMail = (TextView) rootView.findViewById(R.id.hotel_mail);
        tvPhone = (TextView) rootView.findViewById(R.id.hotel_phone);
        ivBack = (ImageView) rootView.findViewById(R.id.activity_hotel_reservation_ala_action_bar_back);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onNavigateBack();
            }
        });
    }

    public void setInfo(final Reservations.HotelReservation reservation) {
        String checkInTime = TimeHelper.getFormattedDateYMD(context, reservation.getCheckIn());
        String checkOutTime = TimeHelper.getFormattedDateYMD(context, reservation.getCheckOut());
        int stayDuration = TimeHelper.getStayDuration(reservation.getCheckIn(), reservation.getCheckOut());
        String stayDurationString = Integer.toString(stayDuration).concat(" ").concat(context.getString(R.string.days));
        tvCheckIn.setText(checkInTime);
        tvCheckOut.setText(checkOutTime);
        tvDuration.setText(stayDurationString);
        tvConfirmationNumber.setText(reservation.getBookingDetails().getConfirmationNumber());
        tvHotelAddress.setText(reservation.getAddress().getStreet());
        tvHotelAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onMapClicked();
            }
        });
        tvPhone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onPhoneClicked();
            }
        });
        tvPhone.setText(reservation.getPhone());
    }

    public void showProgress() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                progressDialog.show();
            }
        });
    }

    public void hideProgress() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (progressDialog != null && progressDialog.isShowing()) {
                    progressDialog.dismiss();
                }
            }
        });
    }

    public void setTitle(final String title) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                tvTitle.setText(title);
            }
        });
    }

    public interface HotelReservationViewListener {
        void onMapClicked();

        void onPhoneClicked();

        void onNavigateBack();
    }
}
