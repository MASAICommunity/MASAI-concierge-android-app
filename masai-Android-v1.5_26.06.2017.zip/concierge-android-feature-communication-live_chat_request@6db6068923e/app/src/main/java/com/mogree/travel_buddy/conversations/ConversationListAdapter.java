package com.mogree.travel_buddy.conversations;

import android.content.Context;
import android.support.annotation.NonNull;
import android.text.Spannable;
import android.text.SpannableString;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.chat.ChatUtilities;
import com.mogree.travel_buddy.core.communication.ConnectionManager;
import com.mogree.travel_buddy.core.communication.HostConnection;
import com.mogree.travel_buddy.core.helper.RealmHelper;
import com.mogree.travel_buddy.core.helper.TimeHelper;
import com.mogree.travel_buddy.core.model.Message;
import com.mogree.travel_buddy.core.model.MessageAttachment;
import com.mogree.travel_buddy.core.model.PermissionQuery;
import com.none.emojioneandroidlibrary.Emojione;

/**
 * Created by Semko on 2016-12-02.
 */

class ConversationListAdapter extends ArrayAdapter<HostConnection> {

    ConversationListAdapter(Context context) {
        super(context, R.layout.item_host_list);
    }

    @Override
    public int getCount() {
        return ConnectionManager.getInstance().getHostConnectionList().size();
    }

    @NonNull
    @Override
    public View getView(int connectionPositionOnList, View convertView, @NonNull ViewGroup parent) {
        ViewHolder viewHolder;
        if (convertView == null) {
            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.item_connection_list, parent, false);
            viewHolder.tvName = (TextView) convertView.findViewById(R.id.item_connection_list_name);
            viewHolder.tvLastMessage = (TextView) convertView.findViewById(R.id.item_connection_list_last_message);
            viewHolder.tvTimeSinceLastMessage = (TextView) convertView.findViewById(R.id.item_connection_list_last_message_time);
            viewHolder.tvLogoText = (TextView) convertView.findViewById(R.id.conversation_item_logo_text);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        Message latestMessage = RealmHelper.getInstance().getLatestMessage(connectionPositionOnList);
        Object[] trainsOrPlaces = null;
        boolean isPermissionRequest = false;
        Spannable messageText = new SpannableString("");
        if (latestMessage != null) {
            String whosMessage = ChatUtilities.getAppropriateMessageSender(latestMessage);
            if (latestMessage.getMessage().startsWith("{") || latestMessage.getMessage().startsWith("[")) {
                trainsOrPlaces = ChatUtilities.getTrains(latestMessage.getMessage());
                if (trainsOrPlaces == null) {
                    trainsOrPlaces = ChatUtilities.getGooglePlaces(latestMessage.getMessage());
                }
                PermissionQuery permissionQuery = ChatUtilities.getPermissionQuery(latestMessage.getMessage());
                if (permissionQuery != null) {
                    isPermissionRequest = true;
                }
            }
            if (trainsOrPlaces != null && trainsOrPlaces.length > 0) {
                messageText = new SpannableString(getContext().getText(R.string.suggested_connections).toString());
            } else if (isPermissionRequest) {
                messageText = new SpannableString(getContext().getText(R.string.request_travelfolder_permission).toString());
            } else if (latestMessage.getLocation() != null) {
                messageText = new SpannableString(String.format(getContext().getString(R.string.user_shared_location), whosMessage));
            } else if (latestMessage.hasAttachments() && latestMessage.isContentEmpty()) {
                for (MessageAttachment messageAttachment : latestMessage.getAttachments()) {
                    if (messageAttachment.getImageUrl() != null && !messageAttachment.getImageUrl().isEmpty()) {
                        messageText = new SpannableString(String.format(getContext().getString(R.string.user_shared_photo), whosMessage));
                    } else if (messageAttachment.getTitleLink() != null && !messageAttachment.getTitleLink().isEmpty()) {
                        messageText = new SpannableString(String.format(getContext().getString(R.string.user_shared_file), whosMessage));
                    }
                }
            }
            if (messageText.length() == 0) {
                messageText = Emojione.replaceAll(getContext(), latestMessage.getMessage(), false);
            }
        }
        viewHolder.tvName.setText(ConnectionManager.getInstance().getHostConnectionForPos(connectionPositionOnList).getHost().getHumanName());
        viewHolder.tvLogoText.setText(ConnectionManager.getInstance().getHostConnectionForPos(connectionPositionOnList).getHost().getHumanName().substring(0, 2));
        if (latestMessage != null) {
            viewHolder.tvLastMessage.setText(messageText);
            viewHolder.tvTimeSinceLastMessage.setText(TimeHelper.getTimeAgo(getContext(), latestMessage.getTimeStamp()));
            viewHolder.tvLastMessage.setVisibility(View.VISIBLE);
            viewHolder.tvTimeSinceLastMessage.setVisibility(View.VISIBLE);
        } else {
            viewHolder.tvLastMessage.setVisibility(View.INVISIBLE);
            viewHolder.tvTimeSinceLastMessage.setVisibility(View.INVISIBLE);
        }
        return convertView;
    }

    private static class ViewHolder {
        TextView tvName;
        TextView tvLastMessage;
        TextView tvTimeSinceLastMessage;
        TextView tvLogoText;
    }
}
