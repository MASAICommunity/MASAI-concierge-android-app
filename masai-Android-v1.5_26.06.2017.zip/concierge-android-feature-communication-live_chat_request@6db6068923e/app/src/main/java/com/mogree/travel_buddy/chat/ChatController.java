package com.mogree.travel_buddy.chat;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;

import com.google.android.gms.maps.model.LatLng;
import com.mogree.travel_buddy.R;
import com.mogree.travel_buddy.core.communication.ConnectionManager;
import com.mogree.travel_buddy.core.communication.HostConnection;
import com.mogree.travel_buddy.core.helper.C;
import com.mogree.travel_buddy.core.helper.ConnectivityChangeReceiver;
import com.mogree.travel_buddy.core.helper.RealmHelper;
import com.mogree.travel_buddy.core.model.Message;
import com.mogree.travel_buddy.core.model.MessageAttachment;
import com.mogree.travel_buddy.core.model.SyncState;

import java.util.List;

public class ChatController extends ChatLocationController implements ChatView.ChatViewListener, ChatAdapter.OnChatAdapterListener, HostConnection.IHostConnectionCallback, ConnectivityChangeReceiver.INetworkState {
    private ChatAdapter chatAdapter;
    private ChatView view;
    private boolean shouldTryAgain = true;
    private int connectionPositionOnList;
    private Handler handler = new Handler(Looper.getMainLooper());
    private ConnectivityChangeReceiver connectivityChangeReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        view = new ChatView(findViewById(android.R.id.content), this);
        retrievePos();
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        view.setTitle(ConnectionManager.getInstance().getHostConnectionForPos(connectionPositionOnList).getHost().getHumanName());
        chatAdapter = new ChatAdapter(this, connectionPositionOnList, this);
        view.setChatListAdapter(chatAdapter);
        view.updateList(chatAdapter);
        view.showProgress();
        connectOrReconnect();
    }

    @Override
    public void onDisconnected() {
        ConnectionManager.setShouldShowInfoReconnecting(true);
        if (shouldTryAgain) {
            shouldTryAgain = false;
            connectOrReconnect();
        } else {
            view.hideProgress();
        }
    }

    @Override
    public void onConnectedAndLoggedIn() {
        shouldTryAgain = true;
        view.hideProgress();
        if (ConnectionManager.isShouldShowInfoReconnecting()) {
            view.showInfoReconnecting();
            ConnectionManager.setShouldShowInfoReconnecting(false);
        }
        loadMissedMessagesAndSubscribeToRoom();
    }

    private void searchForDuplicateFileMessagesAndRemoveLocal() {
        RealmHelper.getInstance().removeDuplicateImageMessages(connectionPositionOnList, new RealmHelper.IMessageRemovedListener() {
            @Override
            public void messageRemoved() {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        view.updateList(chatAdapter);
                        view.scrollToBottom(chatAdapter);
                    }
                });
            }
        });
    }

    @Override
    public void onNewMessage() {
        C.L("FLEFLEonNewMessage");
        handler.post(new Runnable() {
            @Override
            public void run() {
                searchForDuplicateFileMessagesAndRemoveLocal();
                view.updateList(chatAdapter);
                view.scrollToBottom(chatAdapter);
            }
        });
    }

    @Override
    public void onConnectivityError() {
        view.hideProgress();
    }

    HostConnection.ISendFileCallback filesCallback = new HostConnection.ISendFileCallback() {
        @Override
        public void onFileSent(final String name, final String filePath) {
            C.L("onFileSent");
            chatAdapter.setTemporaryImagePath(filePath, name);
            handler.post(new Runnable() {
                @Override
                public void run() {
                    view.hideImageLoadingMessage();
                }
            });
        }

        @Override
        public void onImageAddedToDatabase() {
            clearImagePath();
            view.updateList(chatAdapter);
            view.scrollToBottom(chatAdapter);
        }

        @Override
        public void onFileTooBigError(final String filePath) {
            C.L("FILEUPLOAD onFileTooBigError");
            RealmHelper.getInstance().removeMessageWithId(connectionPositionOnList, filePath);
            handler.post(new Runnable() {
                @Override
                public void run() {
                    view.hideImageLoadingMessage();
                    view.showFileTooBigError();
                    view.updateList(chatAdapter);
                }
            });
        }

        @Override
        public void onConnectionError(final String filePath) {
            C.L("FILEUPLOAD onConnectionError");
            handler.post(new Runnable() {
                @Override
                public void run() {
                    RealmHelper.getInstance().updateMessageState(connectionPositionOnList, filePath, SyncState.FAILED);
                    view.updateList(chatAdapter);
                    view.hideImageLoadingMessage();
                    view.showUploadFailed();
                }
            });
        }

        @Override
        public void onInvalidFileType(final String filePath) {
            C.L("FILEUPLOAD onInvalidFileType");
            handler.post(new Runnable() {
                @Override
                public void run() {
                    RealmHelper.getInstance().removeMessageWithId(connectionPositionOnList, filePath);
                    view.updateList(chatAdapter);
                    view.hideImageLoadingMessage();
                    view.showInvalidFileType();
                }
            });
        }

        @Override
        public void onServerError(final String filePath) {
            C.L("FILEUPLOAD onServerError");
            handler.post(new Runnable() {
                @Override
                public void run() {
                    RealmHelper.getInstance().updateMessageState(connectionPositionOnList, filePath, SyncState.FAILED);
                    view.updateList(chatAdapter);
                    view.hideImageLoadingMessage();
                    view.showServerError();
                }
            });
        }
    };

    HostConnection.ISendMessagesCallback messagesCallback = new HostConnection.ISendMessagesCallback() {
        @Override
        public void onMessageStateUpdated() {
            C.L("message updated");
            view.updateList(chatAdapter);
            view.scrollToBottom(chatAdapter);
        }

        @Override
        public void onConnectivityError() {
            C.L("message error");
            view.updateList(chatAdapter);
        }
    };

    @Override
    protected void onPause() {
        C.L("onPause");
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        C.L("onStop");
        handler.removeCallbacksAndMessages(null);
        if (connectivityChangeReceiver != null) {
            unregisterReceiver(connectivityChangeReceiver);
        }
    }

    @Override
    protected void onResume() {
        connectivityChangeReceiver = ConnectivityChangeReceiver.registerNetworkStateReceiver(this, this);
        super.onResume();
    }

    private void connectOrReconnect() {
        ConnectionManager.getInstance().getHostConnectionForPos(connectionPositionOnList).connectIfDisconnectedAndSetHostListener(this, this);
    }

    private void retrievePos() {
        connectionPositionOnList = getIntent().getIntExtra(C.EXTRA_HOST_CONNECTION_POSITION, 0);
    }

    private void sendFile(final String filePath) {
        final String roomId = ConnectionManager.getInstance().getHostConnectionForPos(connectionPositionOnList).getHost().getRoomId();
        ConnectionManager.getInstance().getHostConnectionForPos(connectionPositionOnList).requestFileSpaceAndUpload(roomId, filePath, filesCallback);
    }

    private void loadMissedMessagesAndSubscribeToRoom() {
        handler.post(new Runnable() {
            @Override
            public void run() {
                final String roomId = ConnectionManager.getInstance().getHostConnectionForPos(connectionPositionOnList).getHost().getRoomId();
                ConnectionManager.getInstance().getHostConnectionForPos(connectionPositionOnList).loadMessagesFromWhileIWasAway(roomId, new HostConnection.IGetMessagesCallback() {
                    @Override
                    public void onMessagesReady() {
                        view.updateList(chatAdapter);
                        view.scrollToBottom(chatAdapter);
                        resendUnsynchronized();
                    }

                    @Override
                    public void onConnectivityError() {
                    }
                });
            }
        });
    }

    private void resendUnsynchronized() {
        ConnectionManager.getInstance().getHostConnectionForPos(connectionPositionOnList).resendUnsynchronizedMessages(messagesCallback, filesCallback);
    }

    @Override
    public void onMessageSendClicked(final String message) {
        view.closeEmojiView();
        final String roomId = ConnectionManager.getInstance().getHostConnectionForPos(connectionPositionOnList).getHost().getRoomId();
        ConnectionManager.getInstance().getHostConnectionForPos(connectionPositionOnList).sendMessage(null, roomId, message, 0, 0, messagesCallback);
    }

    @Override
    public void onBackPressed() {
        if (!view.closeEmojiView()) {
            super.onBackPressed();
        }
    }

    @Override
    public void onNavigateBack() {
        onBackPressed();
    }

    @Override
    public void onMessageClicked(final int messagePosition) {
        final String token = ConnectionManager.getInstance().getHostConnectionForPos(connectionPositionOnList).getHost().getLoginToken();
        final String userId = ConnectionManager.getInstance().getHostConnectionForPos(connectionPositionOnList).getHost().getLiveChatUserId();
        handleMessageClick(this, messagePosition, token, userId);
    }

    private MessageAttachment tmpAttachment;
    private String tmpToken;
    private String tmpUserId;

    public void handleMessageClick(final Context context, final int messagePos, final String token, final String userId) {
        C.L("handeling message Click");
        List<Message> messageList = RealmHelper.getInstance().getMessages(connectionPositionOnList);
        if (messagePos <= messageList.size()) {
            final Message message = messageList.get(messagePos);
            String filePath = null;
            if (message != null) {
                if (message.getAttachments() != null) {
                    for (MessageAttachment attachment : message.getAttachments()) {
                        if (attachment.getTitle().contains(C.TITLE_VALUE_FILE) && !attachment.getTitleUrl().isEmpty()) {
                            filePath = attachment.getTitleUrl();
                        } else {
                            tmpAttachment = attachment;
                            tmpToken = token;
                            tmpUserId = userId;
                            requestPermissionToDownloadOrOpenAttachment();
                        }
                    }
                }
                if (message.getLocation() != null) {
                    ChatUtilities.startMap(this, message.getLocation().getLat(), message.getLocation().getLng(), "");
                }
            }
        }
    }

    @Override
    public void downloadOrOpenAttachment() {
        if (tmpAttachment != null && tmpUserId != null && tmpToken != null) {
            ConnectionManager.getInstance().getHostConnectionForPos(connectionPositionOnList)
                    .downloadOrOpenFileFromAttachment(ChatController.this, tmpAttachment, tmpToken, tmpUserId);
        }
        tmpAttachment = null;
        tmpToken = null;
        tmpUserId = null;
    }

    @Override
    public void onAddClicked() {
        view.showAddOptions();
    }

    @Override
    public void onTakePhotoClicked() {
        takePhoto();
    }

    @Override
    public void onSelectPhotoFromGalleryClicked() {
        selectPhotoFromGallery();
    }

    @Override
    public void onSelectFileClicked() {
        selectFile();
    }

    @Override
    public void fileSelected(final String filePath) {
        if (filePath != null) {
            if (!filePath.startsWith("http")) {
                view.showImageLoadingMessage();
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        sendFile(filePath);
                    }
                });
            } else {
                view.showImageIsNotLocalError();
            }
        } else {
            view.showImageError();
        }
    }

    @Override
    public void onShareLocationClicked() {
        requestLocationAccess();
    }

    @Override
    public void locationAccessGranted() {
        startMap();
    }

    @Override
    public void shareLocation(LatLng latestPosition) {
        if (latestPosition != null) {
            final String roomId = ConnectionManager.getInstance().getHostConnectionForPos(connectionPositionOnList).getHost().getRoomId();
            ConnectionManager.getInstance().getHostConnectionForPos(connectionPositionOnList)
                    .sendMessage(null, roomId, "", (float) latestPosition.latitude, (float) latestPosition.longitude, messagesCallback);
        }
    }

    @Override
    public void onImageLoaded() {
        if (view.getNumberOfNewMessages() == 1 && view.isLastPosVisible()) {
            view.updateList(chatAdapter);
            view.scrollToBottom(chatAdapter);
        }
    }

    @Override
    public void onStateConnected() {
        connectOrReconnect();
    }
}
